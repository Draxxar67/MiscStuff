
function feedback()
{
    // SET MESSAGE VALUES
    var to = "schmittsr1948@verizon.net";
    var cc = " ";
    var bcc = " ";
    var subject = "RE--" + window.location;
    var body = " ";

    // BUILD MAIL MESSAGE COMPONENTS 
    var doc = "mailto:" + to + 
              "?cc=" + cc + 
              "&bcc=" + bcc + 
              "&subject=" + escape(subject) + 
              "&body=" + escape(body); 

    // POP UP EMAIL MESSAGE WINDOW
    window.location = doc;
}

function send_to()
{
    // SET MESSAGE VALUES
    var to = " ";
    var cc = " ";
    var bcc = " ";
    var subject = "" + document.title + "";
    var body = "Try this-- \n\n" + window.location + "";

    // BUILD MAIL MESSAGE COMPONENTS 
    var doc = "mailto:" + to + 
              "?cc=" + cc + 
              "&bcc=" + bcc + 
              "&subject=" + escape(subject) + 
              "&body=" + escape(body); 

    // POP UP EMAIL MESSAGE WINDOW
    window.location = doc;
}

function bookmark()
{
    var url   = "" + window.location + "";
    var title = "" + document.title + "";

    title = title.replace("#", "");

    msgWindow=window.open("","msgWindow","toolbar=no,status=no,menubar=no,scrollbars=yes,width=640,height=480,resizable=yes");
    msgWindow.document.open();
    msgWindow.document.writeln("<html><head><title>Link to this page</title></head>");
    msgWindow.document.writeln("<body>");
    msgWindow.document.writeln("<h4>To save a link to this page to a list so you can have quick and easy access to it later do one of the following:</h4>"); 
    msgWindow.document.writeln("<ul>");
    msgWindow.document.writeln("<li><i>Netscape Navigator</i><br>choose: <tt>Bookmarks | Add Bookmark</tt>");
    msgWindow.document.writeln("<li><i>Internet Explorer</i><br>choose: <tt>Favorites | Add to Favorites</tt>");
    msgWindow.document.writeln("</ul>");
    msgWindow.document.writeln("<hr>");
    msgWindow.document.writeln("<h4>To add a link from <u>your website</u> to <u>this website</u>, copy the code below and paste it into a page in your website:</h4>");
    msgWindow.document.writeln("<p><tt>&lt;a href=\"http://mysite.verizon.net/res148h4j/index.html\"&gt;AbCd Systems - Shareware and Freeware.&lt;/a&gt;</tt>");
    msgWindow.document.writeln("<hr>");
    msgWindow.document.writeln("<h4>To add a link from <u>your website</u> to <u>this page</u>, copy the code below and paste it into a page in your website:</h4>");
    msgWindow.document.writeln("<p><tt>&lt;a href=\"" + url + "\"&gt;" + title + "\"&lt;/a&gt</tt>");

    msgWindow.document.write("</body></html>");
    msgWindow.document.close();
}

