import java.io.*;
import java.awt.*;
import java.math.*;
import java.util.*;
import javax.swing.*;
import java.security.*;
import java.lang.Exception;

/*
 * Title: Lurch
 *
 * Description: A command line file encryption/decryption program. 
 *
 * Encryption notes: In addition to a hard coded cypher key, uses Rot-13 style 
 *              bit rotation (bits are rotated up +128 for encryption and
 *              decryption) and a junk header is added to slightly
 *              offset the file size. An MD5 string is ascii-bumped
 *              and added to the junk header to test for successful
 *              decryption. 
 *
 * Requirements: StringManipulator.class - for methods asciiBump and asciiUnbump
 *
 * Creation date: (25 OCT 2009 07:00:00 AM)
 *
 * @author: Bill Chelonis
 *
 * Author Email: wdchelonis@gmail.com
 *                                                                   
 * Credit goes to Dave Langston for suggestion to include MD5 checking to verify
 * file integrity. 
 *
 * Borrowed method: getMD5String(byte[] b) from java.security.MessageDigest Copyright 2003 Sun Microsystems, Inc.
 *
 */

public class lurch {
  
  public static void main(String[] args){
         boolean tf = true;// default is encrypt
         if((args==null) || (args.length<3)){
            System.out.println("You rang? Format is: java lurch <infile> <outfile> <encrypt> where encrypt is 1 for true or 0 for false");
            System.exit(0);
         }
         if(args[2].equals("0")){
           tf = false;
           System.out.println("set tf= false!");
         }else{
           tf = true;
         }
         // test if outfile already exists
         
         try{
          if(tf==true){
           lurch.copyFile33(new File(args[0]),new File(args[1]));
          }else{
           lurch.uncopyFile33(new File(args[0]),new File(args[1]));
          }
         }catch(Exception e){
           System.out.println("Here is the exception: " + e.getMessage());
           System.exit(0);
         }
         System.out.println("The file has been processed successfully!");
         System.exit(0);// now exit normally
  }

  public static String getFileMD5(File in) throws Exception {
    MessageDigest md = MessageDigest.getInstance("MD5");
    FileInputStream fis = new FileInputStream(in);
    DigestInputStream dis = new DigestInputStream(
                                  fis,
                                  md);
    // read the whole in-file
    try{
        byte[] buf = new byte[1024];
        int i=0;
        while ((i=dis.read(buf)) != -1){ }
    } catch (Exception e) {
        throw e;
    } finally {
        if (fis != null) fis.close();
        if (dis != null) dis.close();// or dis.on(false) to turn OFF the digest
    }
    byte[] result = new byte[1024];
    result = md.digest();// md5Result is now the MD5 hash/bits
    String sResult = lurch.getMD5String(result);
    md.reset();// reset the digest - erases out MD5 hash
    return sResult;
  }
  

  /*
   * This copies a file but also adds a bogus header of 1024 bytes
   * of junk data plus simple byte encryption
   *
   */
  public static void copyFile33(File in, File out) throws Exception {
    // check if the out-file already exists
    if(out.exists()==true){
       System.out.println("File " + out.getName() + " already exists! Aborting. ");
       System.exit(0);
    }
    // last modified date is changed to further disguise the encrypted file
    int year = 81;// the year minus 1900
    int month = 9;// 0-11 are the months
    int day = 25;// days are 1-31
    int hour = 2;// hours are 0-23
    int minute = 23;// minutes are 0-59
    int second = 0;// seconds are 0-59
    java.util.Date eightyOne = new Date(year,month,day,hour,minute,second);
    long eighties = eightyOne.getTime();// milliseconds since 1970
    boolean bLastMod = false;// call it later to set out.setLastModified(eighties);
    FileInputStream fis  = new FileInputStream(in);
    FileOutputStream fos = new FileOutputStream(out);
    JFrame parentComponent = new JFrame();
    String MD5 = new String();
    MessageDigest md = MessageDigest.getInstance("MD5");
    DigestInputStream dis = new DigestInputStream(
                                  fis,
                                  md);
    double inLen = in.length();// length of file in bytes
    double inKLen = (inLen / 1024);// total kilobytes
    double inRemainder = inLen - (inKLen * 1024);// last block of bytes
    String sDisplay = new String("Lurching " + in.getName() + "...");
    int iBlocksRead = 0;// how many 1k blocks read?
    ProgressMonitor pm = new ProgressMonitor(parentComponent,
                                             null,
                                             sDisplay,
                                             0,
                                             (int) inKLen);
    try {
        byte[] buf = new byte[1024];
        byte[] myheader = new byte[1024];// bogus header of Junk Data
        Random generator = new Random(19580427);
        int r = 0;
        for(int i=0;i<1024;i++){
            r = (int) (Math.random() * 26);// random ucase letter A-Z
            myheader[i]=(byte) (65+r);
        }
        fos.write(myheader,0,1024);// write the bogus header
        int j=1024;
        long iBytes = in.length();// bytes
        if(iBytes>=1000000){
          System.out.println("Encrypting " + (iBytes/1000000) + " mb. This could take awhile. Please stand by...");
        }else{
          System.out.println("Encrypting " + iBytes + " bytes. Please stand by...");
        }
        while ((j = dis.read(buf)) != -1) {
            // simple encrypt the buffer
            for(int ii=0;ii<1024;ii++) buf[ii]+=128;// Rot-13 - call again to debug
            fos.write(buf, 0, j);// start offset after junk header
            if(pm.isCanceled()) throw new java.lang.Exception("User cancelled file i/o operation");
            iBlocksRead++;
            pm.setProgress(iBlocksRead);
        }
        System.out.println("Done!");
        pm.setProgress((int)inKLen);// reached end of progress meter
        byte[] result = new byte[1024];
        result = md.digest();// md5Result is now the MD5 hash/bits
        String sResult = lurch.getMD5String(result);
        md.reset();// reset the digest - erases out MD5 hash
        System.out.println("MD5 result==" + sResult);
       /* ------------------------------------------------ */
    // Write the MD5 encrypted string to the bogus header
    try{
        java.io.RandomAccessFile crpt = new java.io.RandomAccessFile(out,"rw");
        crpt.seek(15);// place file pointer at 15th byte
        //byte[] bb = new byte[128];// s2.length()];
        // bb = ;
        sResult = StringManipulator.asciiBump(sResult);
        crpt.write(sResult.getBytes());// cryptedMD5.getBytes());
        crpt.close();
    }catch(IOException e){ System.out.println("RAF exception! "); }

    } 
    catch (Exception e) {
        throw e;
    }
    finally {
        if (fis != null) fis.close();
        if (fos != null) fos.close();
        if (dis != null) dis.close();
        parentComponent.dispose();// destroy the JFrame
    }
     try{
         bLastMod = out.setLastModified(eighties);
     }catch(IllegalArgumentException iae){ }
  }


  public static void uncopyFile33(File in, File out) throws Exception {
    FileInputStream fis  = new FileInputStream(in);
    FileOutputStream fos = new FileOutputStream(out);
    JFrame parentComponent = new JFrame();
    String MD5 = new String();
    MessageDigest md = MessageDigest.getInstance("MD5");
    DigestOutputStream dos = new DigestOutputStream(
                                  fos,
                                  md);
    double inLen = in.length();// length of file in bytes
    double inKLen = (inLen / 1024);// total kilobytes
    double inRemainder = inLen - (inKLen * 1024);// last block of bytes
    String sDisplay = new String("UnLurching " + in.getName() + "...");
    int iBlocksRead = 0;// how many 1k blocks read?
    ProgressMonitor pm = new ProgressMonitor(parentComponent,
                                             null,
                                             sDisplay,
                                             0,
                                             (int) inKLen);
    try {
        byte[] buf = new byte[1024];
        byte[] myheader = new byte[1024];// bogus header of Z's
        for(int i=0;i<1024;i++) myheader[i]=90;
        fis.read(myheader,0,1024);// read the bogus header
        int j=1024;
        while ((j = fis.read(buf)) != -1) {
            // simple de-crypt the buffer
            for(int ii=0;ii<1024;ii++){
              buf[ii]=(byte) (buf[ii]+128);
            }
            // fos.write(buf, 0, j);// start offset after junk header
            dos.write(buf, 0, j);
            if(pm.isCanceled()) throw new java.lang.Exception("User cancelled file i/o operation");
            iBlocksRead++;
            pm.setProgress(iBlocksRead);
        }
        System.out.println("Done!");
        pm.setProgress((int)inKLen);// reached end of progress meter
        byte[] result = new byte[1024];
        result = md.digest();// md5Result is now the MD5 hash/bits
        String sResult = lurch.getMD5String(result);
        md.reset();// reset the digest - erases out MD5 hash
        System.out.println("MD5 result==" + sResult);
       /* ------------------------------------------------ */
    // Read the MD5 encrypted string from the bogus header
    byte[] bb = new byte[34];// s2.length()];
    String s0=new String();
    try{
        java.io.RandomAccessFile crpt = new java.io.RandomAccessFile(in,"r");
        crpt.seek(15);// place file pointer at 15th byte
        crpt.read(bb,0,34);
        s0 = new String(bb);
        s0 = StringManipulator.asciiUnBump(s0);
        crpt.close();
    }catch(IOException e){ System.out.println("RAF exception! "); }
       /* ------------------------------------------------ */
        // compare
        if(s0.equals(sResult)){
             System.out.println("MD5 strings match. File restored successfully.");
        }
    } 
    catch (Exception e) {
        throw e;
    }
    finally {
        if (fis != null) fis.close();
        if (fos != null) fos.close();
        if (dos != null) dos.close();
        parentComponent.dispose();// destroy the JFrame
    }

  }


    /**
     * Helper function that prints unsigned two character hex digits.
     *  Taken from class:  java.security.MessageDigest
     */
    private static void hexDigit(PrintStream p, byte x) {
	char c;
	
	c = (char) ((x >> 4) & 0xf);
	if (c > 9) {
	    c = (char) ((c - 10) + 'a');
	} else {
	    c = (char) (c + '0');
	}
	p.write(c);

	c = (char) (x & 0xf);
	if (c > 9) {
	    c = (char)((c - 10) + 'a');
	} else {
	    c = (char)(c + '0');
	}
	p.write(c);
    }

   // gets the MD5 hex string 
   public static String getMD5String(byte[] b) {
	ByteArrayOutputStream ou = new ByteArrayOutputStream();
	PrintStream p = new PrintStream(ou);
		
        // p.print(this.getClass().getName()+" Message Digest ");
        if (b != null) {
            // p.print("<");
            for(int i = 0; i < b.length; i++)
                hexDigit(p, b[i]);
            // p.print(">");
	} else {
	    p.print("<incomplete>");
	}
	p.println();
	return (ou.toString());
    }


}
