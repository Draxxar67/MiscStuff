
/*
 * Description: A java.awt.Applet object that prompts for password and attempts to
 *              load and decrypt a <code>Crypt.class</code> scrambled textfile.
 * 
 * Requires: StringManipulator.class            
 *              
 * Creation date: (4/10/2000 07:00:00 AM)
 *
 * @author: Draxxar
 *
 * Author Email:   nowhere@nada.net
 */

import java.io.*; 
import java.net.*; 
import java.awt.*; 
import java.lang.*;
import java.util.*;
import java.applet.*; 
import java.awt.event.*;

public class ReadText extends java.applet.Applet implements ItemListener, ActionListener, KeyListener { 
  TextArea textArea=new TextArea(); 
  Label authorisation=new Label("Enter author name here: "); 
  TextField auth_field=new TextField(); 
  String myFileName = new String();
  java.applet.Applet q = new java.applet.Applet();
  Button myLargeFontButton = new Button("Large Font");
  Button mySmallFontButton = new Button("Small Font");
  Button myBlackAndWhiteButton = new Button("B/W Screen");
  Button myWhiteAndBlackButton = new Button("W/B Screen");
  Button myBlackAndGreenButton = new Button("B/G Screen");
  Button myDefaultScreenButton = new Button("Restore Defaults");
  // Password objects
  Label myPasswordLabel = new Label("Password: ",Label.RIGHT);
  Button mySuperButton = new Button("Enter");
  TextField myTextField = new TextField(35);
  String myPassword = new String();
  String[] myWord = new String[200];
  int myCurrentWord = 0;
  // end password objects
  Panel o = new Panel();
  Panel pwd = new Panel();

/**
 * Description: Private method <code>Setup</code> is used to setup the layout and object listeners of the applet.
 *                
 * Creation date: (4/10/2000 07:00:00 AM)
 * @return void
 * @param void
 */
  private void Setup(){
     getAppletContext().showStatus("Loading file...");
     showStatus(getAppletInfo());
     defaultScreen();
     setLayout(null); 
     add(authorisation); 
     add(auth_field); 
     setLayout(new BorderLayout()); 
     // Setup The textArea
     add("Center",textArea);
     o.setLayout(new FlowLayout(FlowLayout.LEFT));
     o.setVisible(true);     
     // Setup The Font Button Panel
     q.setLayout(new FlowLayout(FlowLayout.LEFT)); 
     q.add(myLargeFontButton);
     q.add(mySmallFontButton);
     q.add(myBlackAndWhiteButton);
     q.add(myWhiteAndBlackButton);
     q.add(myBlackAndGreenButton);
     q.add(myDefaultScreenButton);     
     add("South",q);
     myLargeFontButton.addActionListener(this);
     mySmallFontButton.addActionListener(this);
     myBlackAndWhiteButton.addActionListener(this);
     myWhiteAndBlackButton.addActionListener(this);
     myBlackAndGreenButton.addActionListener(this);
     myDefaultScreenButton.addActionListener(this);
     // Setup The Password Panel
     pwd.setLayout(new FlowLayout(FlowLayout.LEFT));
     add("North",pwd);
     pwd.add(myPasswordLabel);
     pwd.add(mySuperButton);
     pwd.add(myTextField);
     myTextField.setEchoChar('*');
     mySuperButton.addActionListener(this);
     this.myPassword = new String("null");
     // Set Initial Cursor Location In Password Field
     myTextField.requestFocus();
     // Disable textArea field from being edited
     textArea.setEditable(false);
     // Show any critical objects that might be hidden
     textArea.show(); 
     q.show();
     this.show();
  }


  /**
  * Description: Private method <code>loadTextArea</code> is used to load a 
  *              <code>Crypt.class</code> <code>keyRot</code> encrypted text file.
  *              Requires Applet Parameter "filename" (grabbed from the <code>defaultScreen</code> method).
  *                
  * Creation date: (4/10/2000 07:00:00 AM)
  * @return void
  * @param void
  */
  private void loadTextArea(){
     String text=null; 
     try{ 
      if(myFileName == null){
         myFileName = "ReadText.htm";
      }
      URL url=new URL(getDocumentBase(),myFileName); 
      DataInputStream stream = new DataInputStream(url.openStream()); 
      // Decryption Routine 
      do { 
        text = stream.readLine(); 
        if (text!=null){
               text = StringManipulator.keyRot(text,myPassword,0);
               textArea.appendText(text+"\r\n");
        }
      } 
      while (text!=null);} 
      catch(IOException e){} 
      textArea.hide(); 
      repaint();
      // Set the textArea cursor to the start position of 1 (note: can't be equal to zero)
      try{
       textArea.setSelectionStart(1);
      }catch(Exception e){}
      textArea.setEditable(false);
      textArea.show(); 
      q.show();
      this.show();
      // hide the password panel now that the text is loaded
      pwd.hide();
      pwd.removeAll();
      this.remove(pwd);
      // reset and repaint the applet layout
      setLayout(new BorderLayout()); 
      repaint();
  }

  /**
  * Description: Method <code>init</code> is used to initialize the applet.
  * Creation date: (4/10/2000 07:00:00 AM)
  * @return void
  * @param void
  */
  public void init() { 
    super.init(); 
    this.update(this.getGraphics());
    Setup();
  } 

  /**
  * Description: Method <code>start</code> is used to repaint and update graphics.
  * Creation date: (4/10/2000 07:00:00 AM)
  * @return void
  * @param void
  */  
  public void start() { 
     repaint();
     this.update(this.getGraphics());
  } 

  /**
  * Description: Method <code>handleEvent</code>
  * Creation date: (4/10/2000 07:00:00 AM)
  * @return void
  * @param void
  */  
  public boolean handleEvent(Event event) { 
     return super.handleEvent(event); 
  } 

  // *******************
  // * actionPerformed *
  // *******************
  /**
  * Description: Method <code>actionPerformed</code> is used for event handling
  *              on the internal button java.applet.Applet <code>q</code> (panel). 
  *
  * Creation date: (4/10/2000 07:00:00 AM)
  * @return void
  * @param void
  */  
  public void actionPerformed(ActionEvent event) {
      String command = event.getActionCommand();
      if (command == "Large Font"){
         largeFont();    
      }                              
      if (command == "Small Font"){
         smallFont();
      }      
      if (command == "B/W Screen"){
        Color myBackColor = new Color(0,0,0);
        textArea.setBackground(myBackColor);
        Color myForeColor = new Color(255,255,255);
        textArea.setForeground(myForeColor);
      }
      if (command == "W/B Screen"){
        Color myBackColor = new Color(255,255,255);
        textArea.setBackground(myBackColor);
        Color myForeColor = new Color(0,0,0);
        textArea.setForeground(myForeColor);
      }
      if (command == "B/G Screen"){
        Color myBackColor = new Color(0,0,0);
        textArea.setBackground(myBackColor);
        Color myForeColor = new Color(84,255,7);
        textArea.setForeground(myForeColor);
      }
      if (command == "Restore Defaults"){
        defaultScreen();                
      }
      if (command == "Enter"){
	 Toolkit.getDefaultToolkit().beep();
	 this.setMyPassword(myTextField.getText());
         pwd.setVisible(false);
         this.setVisible(true);
         o.setVisible(true);
         q.setVisible(true);     
         textArea.setVisible(true);
         textArea.show(); 
         q.show();
         this.show();
         loadTextArea();
      }   
    }

   /**
   * Description: Method <code>largeFont</code> is used to set large font size.
   * Creation date: (4/10/2000 07:00:00 AM)
   * @return void
   * @param void
   */  
   public void largeFont(){
         /* NOTE: Alternates to try: Arial, Dialog, java.awt.Font.BOLD, java.awt.Font.PLAIN, 
          *        "Courier New" = good for msie browsers, "Ariel" = good for both msie & netscape
          */
         java.awt.Font ft = new java.awt.Font("Ariel",java.awt.Font.PLAIN,20);
         textArea.setFont(ft);     
    }

   /**
   * Description: Method <code>smallFont</code> is used to set small font size.
   * Creation date: (4/10/2000 07:00:00 AM)
   * @return void
   * @param void
   */  
   public void smallFont(){
        java.awt.Font ft = new java.awt.Font("Ariel",java.awt.Font.PLAIN,12);
        textArea.setFont(ft);     
   }

   /**
   * Description: Method <code>defaultScreen</code> is used to grab applet params and setup or re-setup the default screen.
   * Creation date: (4/10/2000 07:00:00 AM)
   * @return void
   * @param void
   */  
   public void defaultScreen(){
     myFileName = getParameter("filename");
     String myFR = getParameter("foregroundRed");
     String myFG = getParameter("foregroundGreen");
     String myFB = getParameter("foregroundBlue");
     String myBR = getParameter("backgroundRed");
     String myBG = getParameter("backgroundGreen");
     String myBB = getParameter("backgroundBlue");
     int myR = 0;
     int myG = 0;
     int myB = 0;                
     int myForR = 255;
     int myForG = 255;
     int myForB = 255;
     if((myFR == null) || (myFG == null) || (myFB == null)) {
        myForR = 0;
        myForG = 0;
        myForB = 0;
       }else{
        try {
         myForR = Integer.valueOf(myFR).intValue();
         myForG = Integer.valueOf(myFG).intValue();
         myForB = Integer.valueOf(myFB).intValue();
      } catch(Exception e) {}
     }
     if((myBR == null) || (myBG == null) || (myBB == null)) {
        myR = 255;
        myG = 255;
        myB = 255;
      }else{
        try{
         myR = Integer.valueOf(myBR).intValue();
         myG = Integer.valueOf(myBG).intValue();
         myB = Integer.valueOf(myBB).intValue();
      } catch(Exception e) {}
     }
     /* Some Colors to try:
      *  forest green = 75, 90, 125
      *  white = 255, 255, 255
      *  pink = 255, 153, 255
      *  blue = 51, 0, 255
      *  yellow = 255, 255, 51
      *  green = 00, 255, 51
      *  red = 255, 00, 00
      *  orange = 255, 102, 51
      *  brown = 153, 102, 51
      *  gray = 102, 102, 102
      *  purple = 102, 00, 153
      *  sky blue = 00, 255, 25
      */ 
     // Set Applet Color Defaults
     Color myBackColor = new Color(0,0,0);        // Default black background
     textArea.setBackground(myBackColor);
     Color myForeColor = new Color(255,255,255);  // Default white foreground 
     textArea.setForeground(myForeColor);
     // Try overriding defaults with applet color parameters
     try {
       Color background = new Color(myR, myG, myB);
       Color foreground = new Color(myForR, myForG, myForB);
       textArea.setBackground(background);
       textArea.setForeground(foreground);
      }catch (Exception e) { }
      smallFont();
    }

   // **************************
   // * itemStateChanged Event *
   // **************************
   /**
   * Description: Method <code>itemStateChanged</code> is used to periodically check on item action listeners.
   * Creation date: (4/10/2000 07:00:00 AM)
   * @return void
   * @param void
   */  
    public void itemStateChanged(ItemEvent event) {
      String command = (String) event.getItem();
    }

   // ********************************************
   // * KeyTyped, KeyReleased, KeyPressed Events *
   // ********************************************
   public void keyTyped(KeyEvent e){}
   public void keyReleased(KeyEvent e) {}
   public void keyPressed(KeyEvent e){
	int key = e.getKeyCode();
	if (key == KeyEvent.VK_ENTER){
            // Do Something if applet senses the keyboard "Enter" key (note: NOT the "Enter" applet button) was pressed . . .    
            // Note: Omitted additional decryption code here as some browsers may have a problem with this particular listener event
	}
   }

  /**
  * Description: Method <code>update</code> is used to repaint the applet.
  * Creation date: (4/10/2000 07:00:00 AM)
  * @return void
  * @param g Graphics
  */  
  public void update(Graphics g){
      paint(g);
  }

  /**
  * Description: Method <code>paint</code> is used to paint the applet.
  * Creation date: (4/10/2000 07:00:00 AM)
  * @return void
  * @param void
  */  
  public void paint(java.awt.Graphics g) {  
  }


  /**
  * Creation date: (12/08/2000 09:34:36 AM)
  * @return boolean
  * @param a java.lang.String
  * @deprecated please use checkPassword2
  */
  public boolean checkPassword(String a) {
	String s = new String(this.getMyPassword());
	if (s.compareTo(a) == 0)
	   return true;
	else
	   return false;           
  }
  
  /**
  * Description: When called, getMyPassword() will return the myPassword variable
  * Creation date: (12/08/2000 08:04:07 AM)
  * @return java.lang.String
  */
  public String getMyPassword() {
	return this.myPassword;
  }

  /**
  * Description: When called, setMyPassword(StringSent) will set the myPassword variable
  * Creation date: (12/08/2000 09:29:01 AM)
  * @version 1.0
  * @return void
  * @param a java.lang.String 
  */
  public void setMyPassword(String a) {
	this.myPassword = a;            
  }

  /**
  * Description: When called killMyPassword() will set it to an empty String
  * Creation date: (12/08/2000 09:29:01 AM)
  * @version 1.0
  */
  public void killMyPassword() {
	this.myPassword = new String("");
  }
  
  /**
  * Description: When called, superParse(TextField field) will parse the myWord[] array
  * Creation date: (12/08/2000 09:29:01 AM)
  * @version 1.0
  * @return void
  * @param TextField field
  */
  private void superParse(TextField field){
      int i;
      String grabTxt = field.getText();
      field.setText("");
      // grabTxt = grabTxt.toUpperCase();
      StringTokenizer st = new StringTokenizer(grabTxt," ");
      for(i = 0; i < 100;i++){
	   myWord[i] = "";
	 }
      i = 0;
      while (st.hasMoreTokens()){
	myWord[i] = (String) (st.nextToken());
	// myWord[i] = (String) myWord[i].toUpperCase();
	myWord[i] = (String) myWord[i];
	i++;
      }
  }  

/**
 * Description: When called, checkWords() will return the String myPassword to the checkPassword2() method
 * Creation date: (12/08/2000 09:29:01 AM)
 * @version 1.0
 * @return java.lang.String
 * @param void
 */
private String checkWords(){
	  String grabTxt = myTextField.getText();
	  myCurrentWord = 0;
	  // myWord[myCurrentWord] = "";
	  superParse(myTextField);
	  String tempStringY = new String(myWord[0]);
	  // myWord[0] = " ";
	  return tempStringY;
	  }

  /**
  * Format: checkPassword2(String password you want user to type)
  *
  * Description: use this to check if a user has typed a password matching the string password you are 
  *              sending to this method
  *
  * Example: if (myOverridePrintPassPrompterObject.checkPassword("xyzzyy"))
  *                         System.out.println("You entered the correct password!");
  * 
  * Creation date: (12/08/2000 09:34:36 AM)
  * @return boolean
  * @param a java.lang.String
  */
  public boolean checkPassword2(String a) {
	String s = new String(checkWords());
	if (s.compareTo(a) == 0)
	   return true;
	else
	   return false;           
  }

} 
