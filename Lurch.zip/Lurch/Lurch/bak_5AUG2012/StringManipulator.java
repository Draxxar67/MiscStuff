
/*
 * Description: A java.lang.String object manipulator class that allows
 *              methods similar to the BASIC Language MID$, LEFT$, and RIGHT$ commands
 *              using </code>mids</code>,<code>lefts</code>, and <code>rights</code>.
 *              Also allows use of a key rotation cypher </code>keyRot</code>.
 *              Also allows use of ascii number bumping and un-bumping routines
 *              <code>asciiBump</code> and <code>asciiUnBump</code>.
 *
 * Creation date: (4/10/2000 07:00:00 AM)
 *
 * @author: Draxxar
 *
 * Author Email: nowhere@nada.net  
 */

public class StringManipulator {

 /**
 * Description: Use <code>asciiBump</code> to manipulate a java.lang.String object, increasing all ascii characters by one.
 * Creation date: (4/10/2000 07:00:00 AM)
 * @return java.lang.String
 * @param mySendString java.lang.String
 */
 public static java.lang.String asciiBump(java.lang.String mySendString){
    java.lang.StringBuffer cc = new java.lang.StringBuffer(mySendString);
    for (int x = 0; x < mySendString.length();x++){
      String ss = new String(cc);
      char dd = ' ';
      dd = (char) (ss.charAt(x) + 1);
      cc.setCharAt(x,dd);
    }
    String ss = new String(cc);
    return ss;
  }

 /**
 * Description: Use <code>asciiUnBump</code> to manipulate a java.lang.String object, decreasing all ascii characters by one.
 * Creation date: (4/10/2000 07:00:00 AM)
 * @return java.lang.String
 * @param mySendString java.lang.String
 */
 public static java.lang.String asciiUnBump(java.lang.String mySendString){
    java.lang.StringBuffer cc = new java.lang.StringBuffer(mySendString);
    for (int x = 0; x < mySendString.length();x++){
      String ss = new String(cc);
      char dd = ' ';
      dd = (char) (ss.charAt(x) - 1);
      cc.setCharAt(x,dd);
    }
    String ss = new String(cc);
    return ss;
 }

 /**
 * Description: Use <code>lefts</code> to manipulate a java.lang.String object like 
 *              the LEFT$ command in the BASIC Language. When String mySendString 
 *              is passed to this method along with int y, the method <code>lefts</code>
 *              returns a new String object y characters long from the left of mySendString.
 *              
 *              The following example outputs "Test" when run: 
 *                  java.lang.String a = new java.langString("Testing");
 *                  System.out.println(StringManipulator.lefts(a,4));
 *                
 * Creation date: (4/10/2000 07:00:00 AM)
 * @return java.lang.String
 * @param mySendString java.lang.String, y int
 */
 public static java.lang.String lefts(java.lang.String mySendString,int y){
     java.lang.StringBuffer cc = new java.lang.StringBuffer(mySendString.length());
     for(int x = 0;x < y;x++){
        String ss = new String(mySendString);
        char dd = ' ';
        dd = (char) (ss.charAt(x));
        cc.append(dd);   
     }
     String ss = new String(cc);
     return ss;
  }

 /**
 * Description: Use <code>rights</code> to manipulate a java.lang.String object like 
 *              the RIGHT$ command in the BASIC Language. When String mySendString 
 *              is passed to this method along with int y, the method <code>rights</code>
 *              returns a new String object y characters long from the right of mySendString.
 *              
 *              The following example outputs "ing" when run: 
 *                  java.lang.String a = new java.langString("Testing");
 *                  System.out.println(StringManipulator.rights(a,3));
 *                
 * Creation date: (4/10/2000 07:00:00 AM)
 * @return java.lang.String
 * @param mySendString java.lang.String, y int
 */
 public static java.lang.String rights(java.lang.String mySendString,int y){
     java.lang.StringBuffer cc = new java.lang.StringBuffer(mySendString.length());
     for(int x = mySendString.length() - y;x < mySendString.length();x++){
        String ss = new String(mySendString);
        char dd = ' ';
        dd = (char) (ss.charAt(x));
        cc.append(dd);
     }
     String ss = new String(cc);
     return ss;    
  }

 /**
 * Description: Use <code>mids</code> to manipulate a java.lang.String object like 
 *              the MID$ command in the BASIC Language. When String mySendString 
 *              is passed to this method along with int y and int z, the method <code>mids</code>
 *              returns a new String object z characters long from position y of mySendString.
 *              
 *              The following example outputs "stin" when run: 
 *                  java.lang.String a = new java.langString("Testing");
 *                  System.out.println(StringManipulator.mids(a,3,4));
 *                
 * Creation date: (4/10/2000 07:00:00 AM)
 * @return java.lang.String
 * @param mySendString java.lang.String, y int, z int
 */
 public static java.lang.String mids(java.lang.String mySendString,int y,int z){
     java.lang.StringBuffer cc = new java.lang.StringBuffer(mySendString.length());
     for(int x = (y - 1);x < (y + z - 1);x++){
        String ss = new String(mySendString);
        char dd = ' ';
        dd = (char) (ss.charAt(x));
        cc.append(dd);
     }
     String ss = new String(cc);
     return ss;    
  }

 /**
 * Description: Use <code>keyRot</code> to manipulate a java.lang.String object
 *              by either encrypting or decrypting it. When String mySendString
 *              is passed to this method along with String mySendKey (the password),
 *              and int encode (true/false),  the method <code>keyRot</code> returns 
 *              a new String object that is encrypted/decrypted based on int encode 
 *              (1 for encode, 0 for decode).
 *              
 *              The following example outputs "�������" when run: 
 *                  java.lang.String a = new java.langString("Testing");
 *                  System.out.println(StringManipulator.keyRot(a,"password",1));
 *
 *              Note: This uses the key rotation cypher, a simple yet effective method
 *              of encryption that takes an input string and bumps the ascii value of each
 *              character up by the ascii value of the current pointer to a character within 
 *              the password string. It bumps the ascii up if encrypted, or down if decrypted. 
 *              Values over 255 (the max possible ascii value) are decreased by 255 and values
 *              under 0 are increased by 255 to keep the encryption within 255 possible
 *              ascii character combinations.
 *                
 * Creation date: (4/10/2000 07:00:00 AM)
 * @return java.lang.String
 * @param mySendString java.lang.String, mysendKey java.lang.String,encode int
 */
 public static java.lang.String keyRot(java.lang.String mySendString, java.lang.String mySendKey,int encode){
   java.lang.StringBuffer cc = new java.lang.StringBuffer(mySendString.length());
	 java.lang.String b = new String(mySendString);
	 int d = 0;
	 int mykeypointer = 1;
         /* Note: use b.length() because otherwise code won't work.
          *       mySendString.length() would be a bug in the for loop below.
          *       Reason: because we modify mySendString to become shorter at the end of each pass
          */
         for (int x = 0;x < b.length();x++){
		 char dd = ' ';
		 if (encode == 1){
			try{
			   d = 0;
			   java.lang.Character tempy = new java.lang.Character(lefts(mySendString,1).charAt(0));
			   d = tempy.hashCode();			   
			   java.lang.Character tempz = new java.lang.Character(mids(mySendKey,mykeypointer,1).charAt(0));
			   d = d + tempz.hashCode();
			  }catch(NumberFormatException err){ System.out.println("Error 1!"); }
		 }
                 if (encode == 0){
			try{
			   d = 0;
			   java.lang.Character tempy = new java.lang.Character(lefts(mySendString,1).charAt(0));
			   d = tempy.hashCode();			   
			   java.lang.Character tempz = new java.lang.Character(mids(mySendKey,mykeypointer,1).charAt(0));
			   d = d - tempz.hashCode();
                          }catch(NumberFormatException err){ System.out.println("Error 1!"); }			  
                 }
                 if (d > 255)
                    d = d - 255;
                 if (d < 0)
		    d = d + 255;			
		 dd = (char) d;
		 cc.append(dd);
		 mySendString = new String(rights(mySendString,(mySendString.length() -1)));
		 mykeypointer++;
		 if (mykeypointer > mySendKey.length())
		    mykeypointer = 1;
	 }
	 String ss = new String(cc);
	 return ss;
  }

}
