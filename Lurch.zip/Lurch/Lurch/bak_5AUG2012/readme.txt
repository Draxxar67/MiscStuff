Lurch version 1.0
by Bill Chelonis

DISCLAIMER: Use Lurch and related utilities at your own risk! 
This is a cheap file scrambling type utility.

Origin: The Lurch command line utility was born on 25OCT2009.
Compiled in java version 1.4.2_04 (Java(TM) 2 Runtime 
Environment).

        
This Java utility provides a relatively fast and simple form of 
data hiding. The Lurch-encryption scheme is a step beyond simple
byte-shifting and should not be considered true data encryption
but rather a relatively fast method of hiding data, especially
large files. 

To encrypt a file in the windows operating system:

1. Copy the Lurch *.class files from this directory to a
   desired path on your computer. If you have the Java Developer
   Kit enstalled, copy it to your jdk2\bin directory and run
   the program from there.
    
2. Go to the "start" menu and click on "run" and type in "cmd"
   (minus the quotes) and hit enter.

3. To encrypt a file, for example this readme.txt file, and
   create a simple "lurch" encrypted file named jumbled.dat,
   from the command prompt type:
      java lurch readme.txt jumbled.dat 1

4. To decrypt jumbled.dat to a new textfile named readme2.txt,
   from the command prompt type:
      java lurch jumbled.dat readme2.txt 0
   (This restores your encrypted data to a file named
   readme2.txt in this example).

This works for all file types.

---------------------------------------------------------------

LurchDir 
  version 0.01

This is a BETA version of LurchDir. Use at your own risk!
There is no "Un-LurchDir" utility to un-Lurch entire file
directories just yet. This will, however, Lurch entire directories
so you do not have to manually Lurch files one at a time. You
may then later on un-lurch the files with the normal "lurch"
command as explained above.

LurchDir can "Lurch" directories with up to 114 (or so) files.
The reason for the limitation is the hardcoded output file
array has only 114 (or so) elements. 

To encrypt a file directory in the windows operating system:

1. Copy the Lurch *.class files from this directory to a
   desired path on your computer. If you have the Java Developer
   Kit enstalled, copy it to your jdk2\bin directory and run
   the program from there.
    
2. Go to the "start" menu and click on "run" and type in "cmd"
   (minus the quotes) and hit enter.

3. To encrypt a directory, for example c:\games, and have 
   the resulting "lurch" encrypted files created in the current
   directory (*.ntf files plus one *.785 encrypted index file) 
   use this command:
      java lurchDir c:\games

4. To view the 01030208.785 index file of lurched files, 
   open file "ReadText.htm" and enter "unlurch" in the text
   field and click the "enter" button. This will show you
   what the *.ntf files were lurched from, so that you may
   later on unlurch them manually one at a time as needed.
