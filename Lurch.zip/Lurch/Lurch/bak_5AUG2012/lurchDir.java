import java.io.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.security.*;
import java.lang.Exception;

// Lurch version: 1.02  27OCT2009

/*
 * Title: Lurch
 *
 * Description: A simple Rot-13 style bit rotation File encryption   
 *              scheme. Bits are rotated up +128 for encryption and
 *              decryption and a junk header is added to slightly
 *              offset the file size. An MD5 string is ascii-bumped
 *              and added to the junk header to test for successful
 *              decryption. File "Lurching" by no means provides safe
 *              and secure file encryption but is a rapid method of
 *              obscuring data.
 *
 * Improvements not yet implemented:
 *              1. A file pick-list to add a series of files or directories
 *                 for Lurching.
 *              2. Encrypting the original file name somewhere in the header
 *                 for optional UnLurching back to the original file name.
 *              3. Optional Key-Rotation Style Cypher for more secure
 *                 data encryption.
 *
 * Trivia: Named Lurch (after the butler in the TV series "The Adam's Family")
 *         because this file was born near Holloween.
 *
 * Requirements: StringManipulator.class - for methods asciiBump and asciiUnbump
 *
 * Creation date: (25/10/2009 07:00:00 AM)
 *
 * @author: Draxxar
 *
 * Author Email: nowhere@nada.net
 *                                                                   
 * Credits: D.L. - for help, direction and ideas on how to do this.
 *          Borrowed method: getMD5String(byte[] b) from java.security.MessageDigest Copyright 2003 Sun Microsystems, Inc.
 */

public class lurchDir {

  
  // 114 lurch files and counting...
  public static final String[] lurchedFiles = {
              "aries","aquarius","galifrey","vulcan","romulus","hoth","endor",
              "crater","zenith","tark","alien_five","castle","mirro",
              "andromeda","persephone","triton",
              "mercury","venus","earth","mars","saturn","neptune",
              "jupiter","uranus","pluto",
              "ursa_major","ursa_minor","triangulum",
              "serpens","sculptor","carnia",
              "canis_maj","canis_min","bootes",
              "epsilon","auriga","aquila","caelum","camelopardalis",
              "cancer","canes_venatici","cor_caroli","sirius",
              "capriornus","alpha_capricorni","centaurus","alpha_centauri",
              "omega_centauri","proxima_centauri","cepheus","cetus",
              "delta_cephei","mu_cephei","mira_omicron_ceti","chamaeleon",
              "circinus","alpha_circini","columba","coma_berenices",
              "corona_australis","corona_borealis","corvus","crux",
              "alpha_crucis","gamma_crucis","cygnus","alpha_cygni",
              "beta_cygni","cygni","chi_cygni","delphinus","dorado",
              "s_doradus","draco","quadrantids","draconids","equuleus",
              "alpha_equulei","eridanus","omicron_2_eridani","epsilon_eridani",
              "fornax","gemini","castor","eta_geminorum","grus","alpha_gruis",
              "beta_gruis","gamma_gruis","hercules","ras_algethi","horologium",
              "r_horologii","hydra","r_hydrae","v_hydrae","hydrus",
              "vw_hydri","indus","epsilon_indi","lacerta","bl_lacertae",
              "gamma_leonis","r_leonis","r_leonis_minoris","leonids",
              "lepus","gamma_leporis","libra","delta_librae","s_librae",
              "lupus","ru_lupi","lynx",
              //
              "epsilon_lyrae","beta_lyrae","mensa","alpha_mensae",
              "beta_mensae","microscopium","r_microscopii","m50",
              "musca","beta_muscae","norma","octans","sigma_octanis",
              "ophiuchus","rs_ophiuchi","barnards_star","orion",
              "betelgeuse","rigel","orion_nebula","pavo","pegasus",
              "stephans_quintet","perseus","algol","perseids","phoenix",
              "sx_phoenicis","pictor","beta_pictoris","kaptens_star",
              "pisces","zeta_piscium","van_maanens_star","piscis_austrinus",
              "formalhaut","zeta_puppis","l2_puppis","t_pyxidis",
              "reticulum","r_reticuli","sagitta","u_sagittae","v_sagittae",
              "sagittarius","lagoon_nebula","trifid_nebula","omega_nebula",
              "scorpius","antares","beta_scorpii","butterfly_cluster",
              "scorpius_x1","scutum","r_scuti","wild_duck_cluster",
              "sextans","spindle_galaxy","taurus","the_pleiades",
              "the_hyades","aldebaran","alpha_tauri","the_crab_nebula",
              "telescopium","rr_telescopii","pinwheel_galaxy",
              "r_trianguli_australis","s_trianguli_australis",
              "tucana","47_tucanae","the_small_magellanic_cloud",
              "the_owl_nebula","vela","polaris","alpha_ursae_minoris",
              "gamma_velorum","virgo","spica","porima","sombrero_galaxy"
              };


  public static void main(String[] args){
         if(args==null){
            System.out.println("You rang? Format is: java lurchDir <directoryName>");
            System.exit(0);
         }
         System.out.println("LurchedFiles.length()== " + lurchedFiles.length);
         File myDir = new File(args[0]);
         // File myDir = new File("C:\\Users\\MainAdmin\\Documents\\sw\\ut\\Server");
         if(myDir.isDirectory()!=true){
            System.out.println("Error. LurchDir requires a directory name.");
            System.exit(0);
         }
         System.out.println("Directory: " + myDir.getPath() + " found!");
         File[] myFiles = myDir.listFiles();// includes files and directories in myDir directory
         // ** index.dat - the index file for the directory
         // PrintWriter fosPW; // = new PrintWriter();
         //try{
         //  fosPW = new PrintWriter(new BufferedWriter(new FileWriter("index.ntf")));
         //  fosPW.write(new String("These files have been Lurched!\nLurched I say!"));
         //  fosPW.flush();
         //  // fosPW.close();
         //}catch(IOException e){
         //  System.out.println("Unknown file exception. ");
         //  System.exit(0);
         //}

         //try{
             // java.lang.Runtime.getRuntime().exec("Hello World");// new String("echo HELLO WORLD!"));
        //     Runtime rt = Runtime.getRuntime();
        //     Process proc = rt.exec("dir *.java >> doo.dat");
        // }catch(Exception e){ }
        // System.exit(0);
         // int ii2 = 123;
         //if(1!=2) System.exit(0);

     // File tmpFile;

         // BufferedWriter bw = new BufferedWriter();

     File killFile = new File("index.dat");

     try{
       //File currDir = new File("c:\\lang\\jdk2\\bin");// current dir
       //tmpFile = File.createTempFile(new String("index"),
       //                                    new String("ntf"), // );//,
       //                                   currDir);
       // tmpFile.deleteOnExit();
       PrintWriter fosPW = new PrintWriter(new BufferedWriter(new FileWriter(killFile)));
       fosPW.write(new String("These files have been Lurched!"));
       fosPW.write(new String("\n-----------------------------------------------------------------------------"));
       fosPW.write(new String("\nOriginal                      | Lurched                                      "));
       fosPW.write(new String("\n-----------------------------------------------------------------------------"));
       fosPW.flush();
       String sJunkFile = new String();
         int iCount=0;
         for(int i=0;i<myFiles.length;i++){
             if(myFiles[i].isDirectory()!=true){
                System.out.println("File: " + myFiles[i].getName());
                // do not exceed junk file array length for number of files
                if(iCount<lurchDir.lurchedFiles.length){
                     try{
                       sJunkFile = new String(lurchDir.lurchedFiles[iCount] + "" + iCount + ".ntf");
                       lurch.copyFile33(myFiles[i],new File(sJunkFile));
                       fosPW.write(new String("\n" + myFiles[i].getName() + ", " + sJunkFile));
                       fosPW.flush();
                       System.out.println(lurchDir.lurchedFiles[iCount]);
                       iCount++;
                     }catch(Exception e){
                       System.out.println("Here is the exception: " + e.getMessage());
                       System.exit(0);
                     }
                     fosPW.flush();
                     //catch(IOException ioe){
                     //  System.out.println("IOException: " + ioe.getMessage());
                     //  System.exit(0);
                     //}
                }
             }else{
                System.out.println("Dir: " + myFiles[i].getName());
             }

         }
         fosPW.close();
         // tmpFile.delete();
        }catch(IOException ioe){
          System.out.println("IOException: " + ioe.getMessage());
          System.exit(0);
        }
        // encrypt the index.ntf file
        try{
          // Experimental -
          Crypt.runMe(new String("index.dat"),new String("01030208.785"),new String("13457890whatisyourname3293SIRLANCELOT13714whatisyourquest475917TOSEEKTHEHOLYGRAIL2035437whatistheaverageairspeedvelocityofanunladenswallow5342985701930298018365329123IDONTKNOWTHATaaaaaaaaaaaaaaaaaaaaaaAAAAAAAAAAAAAAAAAAAAAAAAA23457911ishejustsayingah37291MAYBEHEWROTEITASHEDIED24837nobodywritesaaaaaaaaAAAAAAAAAAAAaahastheyredying902937ISITTHECASTLEOFAAAAAAAAAAAAH32373somepeoplecallme32340948TIM0092345813Z"));
          // Public -
          // Crypt.runMe(new String("index.dat"),new String("01030208.785"),new String("unlurch"));
        }catch(Exception e){
          System.out.println("Error: Can't Crypt index.dat!");
          System.exit(0);
        }
        //Date myNewDate = new Date(2008,12,25,6,33);// yyyy,mm,dd,hr,min
        // Date myDate = new Date();// current date and time by default
        // long myTime = myNewDate.getTime();
        
        // myDate.getTime();// returns Time as a long
        try{
          lurchDir.reDateFile(killFile);
        }catch(Exception eoeo){ System.out.println("Exception 1234"); }
        File blammo = new File("01030208.785");
        try{
          lurchDir.reDateFile(blammo);
        }catch(Exception fofo){ System.out.println("Exception 5678"); }
        // try re-naming index.dat
        File jumboLia = new File("jumbo.lia");
        try{
          killFile.renameTo(jumboLia);// new File("jumbo.lia"));
        }catch(Exception e){ }
        // Delete jumbo.lia - this actually deletes the renamed index.dat
        try{
          jumboLia.delete();// killFile.deleteOnExit();
        }catch(Exception e){ }

    /* ------------------------------------------------ *
     * END 3 NOV                                        *
     * -------------------------------------------------*/



        //    killFile.renameTo(new File("jumbo.lia"));// FileSystem.getFileSystem().delete(new file("index.dat"));
        //    long myTime = 
        //    killFile.setLastModified(eighties);
        //}catch(Exception e){
        //  System.out.println("IOException.... : " + e.getMessage());
        //}
        /*

         boolean tf = true;// default is encrypt
         if((args==null) || (args.length<3)){
            System.out.println("You rang? Format is: java lurch <infile> <outfile> <encrypt> where encrypt is 1 for true or 0 for false");
            System.exit(0);
         }
         // System.out.println("args[2]==" + args[2]);
         if(args[2].equals("0")){
           tf = false;
           System.out.println("set tf= false!");
         }else{
           tf = true;
         }
         // test if outfile already exists
         File outFile = new File(args[1]);
         if(outFile.exists()){
           System.out.println("Error. Output file name " + outFile.getName() + " already exists. Please choose a different destination filename. ");
           System.exit(0);
         }
         
         try{
          if(tf==true){
             lurch.copyFile33(new File(args[0]),new File(args[1]));
          }else{
             lurch.uncopyFile33(new File(args[0]),new File(args[1]));
          }
         }catch(Exception e){
           System.out.println("Here is the exception: " + e.getMessage());
           System.exit(0);
         }
         System.out.println("The file has been processed successfully!");
         System.exit(0);// now exit normally
         */
  }

  public static void reDateFile(File in) throws Exception {
    int year = 81;// the year minus 1900
    int month = 9;// 0-11 are the months
    int day = 25;// days are 1-31
    int hour = 2;// hours are 0-23
    int minute = 23;// minutes are 0-59
    int second = 0;// seconds are 0-59
    java.util.Date eightyOne = new Date(year,month,day,hour,minute,second);
    long eighties = eightyOne.getTime();// milliseconds since 1970
    boolean bLastMod = false;// call it later to set out.setLastModified(eighties);
    System.out.println("Trying to re-date file " + in.getName() + " to: " + eightyOne.getTime());
    try{
      bLastMod = in.setLastModified(eighties);
    }catch(IllegalArgumentException iae){ System.out.println("Exception!!"); }
  }


}

