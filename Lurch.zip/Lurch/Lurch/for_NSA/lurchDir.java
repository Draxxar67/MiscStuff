import java.io.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.security.*;
import java.lang.Exception;

// Lurch version: 1.02  27OCT2009

/*
 * Title: lurchDir
 *
 * Requirements: StringManipulator.class - for methods asciiBump and asciiUnbump
 *
 * Creation date: (25/10/2009 07:00:00 AM)
 *
 * @author: Bill Chelonis
 *
 * Author Email: wdchelonis@gmail.com
 *
 */

public class lurchDir {

  
  // WARNING: Hard coded! Do not use for directories over 114 lurch files unless you add to this list...
  public static final String[] lurchedFiles = {
              "aries","aquarius","galifrey","vulcan","romulus","hoth","endor",
              "crater","zenith","tark","alien_five","castle","mirro",
              "andromeda","persephone","triton",
              "mercury","venus","earth","mars","saturn","neptune",
              "jupiter","uranus","pluto",
              "ursa_major","ursa_minor","triangulum",
              "serpens","sculptor","carnia",
              "canis_maj","canis_min","bootes",
              "epsilon","auriga","aquila","caelum","camelopardalis",
              "cancer","canes_venatici","cor_caroli","sirius",
              "capriornus","alpha_capricorni","centaurus","alpha_centauri",
              "omega_centauri","proxima_centauri","cepheus","cetus",
              "delta_cephei","mu_cephei","mira_omicron_ceti","chamaeleon",
              "circinus","alpha_circini","columba","coma_berenices",
              "corona_australis","corona_borealis","corvus","crux",
              "alpha_crucis","gamma_crucis","cygnus","alpha_cygni",
              "beta_cygni","cygni","chi_cygni","delphinus","dorado",
              "s_doradus","draco","quadrantids","draconids","equuleus",
              "alpha_equulei","eridanus","omicron_2_eridani","epsilon_eridani",
              "fornax","gemini","castor","eta_geminorum","grus","alpha_gruis",
              "beta_gruis","gamma_gruis","hercules","ras_algethi","horologium",
              "r_horologii","hydra","r_hydrae","v_hydrae","hydrus",
              "vw_hydri","indus","epsilon_indi","lacerta","bl_lacertae",
              "gamma_leonis","r_leonis","r_leonis_minoris","leonids",
              "lepus","gamma_leporis","libra","delta_librae","s_librae",
              "lupus","ru_lupi","lynx",
              //
              "epsilon_lyrae","beta_lyrae","mensa","alpha_mensae",
              "beta_mensae","microscopium","r_microscopii","m50",
              "musca","beta_muscae","norma","octans","sigma_octanis",
              "ophiuchus","rs_ophiuchi","barnards_star","orion",
              "betelgeuse","rigel","orion_nebula","pavo","pegasus",
              "stephans_quintet","perseus","algol","perseids","phoenix",
              "sx_phoenicis","pictor","beta_pictoris","kaptens_star",
              "pisces","zeta_piscium","van_maanens_star","piscis_austrinus",
              "formalhaut","zeta_puppis","l2_puppis","t_pyxidis",
              "reticulum","r_reticuli","sagitta","u_sagittae","v_sagittae",
              "sagittarius","lagoon_nebula","trifid_nebula","omega_nebula",
              "scorpius","antares","beta_scorpii","butterfly_cluster",
              "scorpius_x1","scutum","r_scuti","wild_duck_cluster",
              "sextans","spindle_galaxy","taurus","the_pleiades",
              "the_hyades","aldebaran","alpha_tauri","the_crab_nebula",
              "telescopium","rr_telescopii","pinwheel_galaxy",
              "r_trianguli_australis","s_trianguli_australis",
              "tucana","47_tucanae","the_small_magellanic_cloud",
              "the_owl_nebula","vela","polaris","alpha_ursae_minoris",
              "gamma_velorum","virgo","spica","porima","sombrero_galaxy"
              };


  public static void main(String[] args){
         if(args==null){
            System.out.println("You rang? Format is: java lurchDir <directoryName>");
            System.exit(0);
         }
         System.out.println("LurchedFiles.length()== " + lurchedFiles.length);
         File myDir = new File(args[0]);
         // File myDir = new File("C:\\Users\\MainAdmin\\Documents\\sw\\ut\\Server");
         if(myDir.isDirectory()!=true){
            System.out.println("Error. LurchDir requires a directory name.");
            System.exit(0);
         }
         System.out.println("Directory: " + myDir.getPath() + " found!");
         File[] myFiles = myDir.listFiles();// includes files and directories in myDir directory

     File killFile = new File("index.dat");

     try{
       PrintWriter fosPW = new PrintWriter(new BufferedWriter(new FileWriter(killFile)));
       fosPW.write(new String("These files have been Lurched!"));
       fosPW.write(new String("\n-----------------------------------------------------------------------------"));
       fosPW.write(new String("\nOriginal                      | Lurched                                      "));
       fosPW.write(new String("\n-----------------------------------------------------------------------------"));
       fosPW.flush();
       String sJunkFile = new String();
         int iCount=0;
         for(int i=0;i<myFiles.length;i++){
             if(myFiles[i].isDirectory()!=true){
                System.out.println("File: " + myFiles[i].getName());
                // do not exceed junk file array length for number of files
                if(iCount<lurchDir.lurchedFiles.length){
                     try{
                       sJunkFile = new String(lurchDir.lurchedFiles[iCount] + "" + iCount + ".ntf");
                       lurch.copyFile33(myFiles[i],new File(sJunkFile));
                       fosPW.write(new String("\n" + myFiles[i].getName() + ", " + sJunkFile));
                       fosPW.flush();
                       System.out.println(lurchDir.lurchedFiles[iCount]);
                       iCount++;
                     }catch(Exception e){
                       System.out.println("Here is the exception: " + e.getMessage());
                       System.exit(0);
                     }
                     fosPW.flush();
                     //catch(IOException ioe){
                     //  System.out.println("IOException: " + ioe.getMessage());
                     //  System.exit(0);
                     //}
                }
             }else{
                System.out.println("Dir: " + myFiles[i].getName());
             }

         }
         fosPW.close();
         // tmpFile.delete();
        }catch(IOException ioe){
          System.out.println("IOException: " + ioe.getMessage());
          System.exit(0);
        }
        // encrypt the index.ntf file
        try{
          // Experimental -
          Crypt.runMe(new String("index.dat"),new String("01030208.785"),new String("unlurch"));
     }catch(Exception e){
          System.out.println("Error: Can't Crypt index.dat!");
          System.exit(0);
        }
        try{
          lurchDir.reDateFile(killFile);
        }catch(Exception eoeo){ System.out.println("Exception 1234"); }
        File blammo = new File("01030208.785");
        try{
          lurchDir.reDateFile(blammo);
        }catch(Exception fofo){ System.out.println("Exception 5678"); }
        // try re-naming index.dat
        File jumboLia = new File("jumbo.lia");
        try{
          killFile.renameTo(jumboLia);// new File("jumbo.lia"));
        }catch(Exception e){ }
        // Delete jumbo.lia - this actually deletes the renamed index.dat
        try{
          jumboLia.delete();// killFile.deleteOnExit();
        }catch(Exception e){ }
  }

  public static void reDateFile(File in) throws Exception {
    int year = 81;// the year minus 1900
    int month = 9;// 0-11 are the months
    int day = 25;// days are 1-31
    int hour = 2;// hours are 0-23
    int minute = 23;// minutes are 0-59
    int second = 0;// seconds are 0-59
    java.util.Date eightyOne = new Date(year,month,day,hour,minute,second);
    long eighties = eightyOne.getTime();// milliseconds since 1970
    boolean bLastMod = false;// call it later to set out.setLastModified(eighties);
    System.out.println("Trying to re-date file " + in.getName() + " to: " + eightyOne.getTime());
    try{
      bLastMod = in.setLastModified(eighties);
    }catch(IllegalArgumentException iae){ System.out.println("Exception!!"); }
  }


}

