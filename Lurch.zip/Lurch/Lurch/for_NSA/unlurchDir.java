import java.io.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.security.*;
import java.lang.Exception;

// Lurch version: 1.02  27OCT2009

/*
 * Title: unlurchDir 
 *
 * Description: BETA - directory un-encryptor.
 *
 * Requirements: StringManipulator.class - for methods asciiBump and asciiUnbump
 *
 * Creation date: (25/10/2009 07:00:00 AM)
 *
 * @author: Bill Chelonis
 *
 * Author Email: wdchelonis@gmail.com
 *
 */

public class unlurchDir {

  
  // 114 lurch files and counting...
  public static final String[] lurchedFiles = {
              "aries","aquarius","galifrey","vulcan","romulus","hoth","endor",
              "crater","zenith","tark","alien_five","castle","mirro",
              "andromeda","persephone","triton",
              "mercury","venus","earth","mars","saturn","neptune",
              "jupiter","uranus","pluto",
              "ursa_major","ursa_minor","triangulum",
              "serpens","sculptor","carnia",
              "canis_maj","canis_min","bootes",
              "epsilon","auriga","aquila","caelum","camelopardalis",
              "cancer","canes_venatici","cor_caroli","sirius",
              "capriornus","alpha_capricorni","centaurus","alpha_centauri",
              "omega_centauri","proxima_centauri","cepheus","cetus",
              "delta_cephei","mu_cephei","mira_omicron_ceti","chamaeleon",
              "circinus","alpha_circini","columba","coma_berenices",
              "corona_australis","corona_borealis","corvus","crux",
              "alpha_crucis","gamma_crucis","cygnus","alpha_cygni",
              "beta_cygni","cygni","chi_cygni","delphinus","dorado",
              "s_doradus","draco","quadrantids","draconids","equuleus",
              "alpha_equulei","eridanus","omicron_2_eridani","epsilon_eridani",
              "fornax","gemini","castor","eta_geminorum","grus","alpha_gruis",
              "beta_gruis","gamma_gruis","hercules","ras_algethi","horologium",
              "r_horologii","hydra","r_hydrae","v_hydrae","hydrus",
              "vw_hydri","indus","epsilon_indi","lacerta","bl_lacertae",
              "gamma_leonis","r_leonis","r_leonis_minoris","leonids",
              "lepus","gamma_leporis","libra","delta_librae","s_librae",
              "lupus","ru_lupi","lynx",
              //
              "epsilon_lyrae","beta_lyrae","mensa","alpha_mensae",
              "beta_mensae","microscopium","r_microscopii","m50",
              "musca","beta_muscae","norma","octans","sigma_octanis",
              "ophiuchus","rs_ophiuchi","barnards_star","orion",
              "betelgeuse","rigel","orion_nebula","pavo","pegasus",
              "stephans_quintet","perseus","algol","perseids","phoenix",
              "sx_phoenicis","pictor","beta_pictoris","kaptens_star",
              "pisces","zeta_piscium","van_maanens_star","piscis_austrinus",
              "formalhaut","zeta_puppis","l2_puppis","t_pyxidis",
              "reticulum","r_reticuli","sagitta","u_sagittae","v_sagittae",
              "sagittarius","lagoon_nebula","trifid_nebula","omega_nebula",
              "scorpius","antares","beta_scorpii","butterfly_cluster",
              "scorpius_x1","scutum","r_scuti","wild_duck_cluster",
              "sextans","spindle_galaxy","taurus","the_pleiades",
              "the_hyades","aldebaran","alpha_tauri","the_crab_nebula",
              "telescopium","rr_telescopii","pinwheel_galaxy",
              "r_trianguli_australis","s_trianguli_australis",
              "tucana","47_tucanae","the_small_magellanic_cloud",
              "the_owl_nebula","vela","polaris","alpha_ursae_minoris",
              "gamma_velorum","virgo","spica","porima","sombrero_galaxy"
              };


  public static void main(String[] args){
         if(args==null){
            System.out.println("You rang? Format is: java unlurchDir <directoryName>");
            System.exit(0);
         }
         System.out.println("LurchedFiles.length()== " + lurchedFiles.length);
         File myDir = new File(args[0]);
         if(myDir.isDirectory()!=true){
            System.out.println("Error. unlurchDir requires a directory name.");
            System.exit(0);
         }
         System.out.println("Directory: " + myDir.getPath() + " found!");
         File[] myFiles = myDir.listFiles();// includes files and directories in myDir directory

     File unlurchTxt = new File("unlurch.txt");
     try{
         FileReader myFileReader = new FileReader(unlurchTxt);
         LineNumberReader in = new LineNumberReader(myFileReader);// extends BufferedReader
         String j = new String();
         int iLine = 0;
         String origFileName = new String();
         String lurchFileName = new String();
         int iComma = 0;

        // for(int i=0;i<myFiles.length;i++){
        //     if(myFiles[i].isDirectory()!=true){
        String dirPath = new String(myDir.getPath() + "\\");
        System.out.println("Dir path: " + dirPath);

         while((j = in.readLine()) != null){
            iLine = in.getLineNumber();
            System.out.println("Line# " + iLine + ": " + j);
            iComma = j.indexOf(",");// location of the comma in the line
            lurchFileName = j.substring(iComma + 2);
            origFileName = j.substring(0,iComma);
            System.out.println("... LurchFile: " + lurchFileName +
                               " origFile: " + origFileName);
            lurch.uncopyFile33(new File(dirPath + lurchFileName),new File(dirPath + origFileName));
         }
         in.close();
     }catch(FileNotFoundException fnfe){
         System.out.println("File Not Found Error: " + fnfe.getMessage());
         if(! unlurchTxt.exists()){
            System.out.println("You need a flatfile named unlurch.txt in the current directory with old file name and lurch file name seperated by one comma in between on each line. UnLurch then reads this file line by line, unLurching lurchFile into originalFile. Use ReadText to help build this flatfile. ");
         }
         System.exit(0);
     }catch(IOException eab){
         System.out.println("IO Error: " + eab.getMessage());
         System.exit(0);
     }catch(Exception efg){
         System.out.println("Exception: " + efg.getMessage());
         System.exit(0);
     } finally {
        // if (in != null) in.close();
     }


  }// end main()

}

