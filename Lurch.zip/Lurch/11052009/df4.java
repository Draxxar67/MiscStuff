import java.awt.*;
import java.io.*;
import java.util.*; // for random 
import javax.swing.*;
import java.security.*;
import java.lang.Exception;

//import java.security.MessageDigest;
//import java.security.DigestInputStream;

public class df4 {
  
  public static void main(String[] args){
       File f1 = new File(args[0]);
       long iBytes = f1.length();// bytes
       System.out.println("" + iBytes + " bytes");
       if(iBytes>=1000000)
         System.out.println("" + (iBytes/1000000) + " mb");
      // copy the file
      try{
          df4.copyFile3(new File(args[0]),new File(args[1]));
      }catch(Exception e){}
      // uncopy it!
      try{
          df4.uncopyFile3(new File(args[1]),new File("meep.map"));
      }catch(Exception e){}
  }

  public static String getFileMD5(File in) throws Exception {
    MessageDigest md = MessageDigest.getInstance("MD5");
    FileInputStream fis = new FileInputStream(in);
    DigestInputStream dis = new DigestInputStream(
                                  fis,
                                  md);
    // read the whole in-file
    try{
        byte[] buf = new byte[1024];
        int i=0;
        while ((i=dis.read(buf)) != -1){ }
    } catch (Exception e) {
        throw e;
    } finally {
        if (fis != null) fis.close();
        if (dis != null) dis.close();// or dis.on(false) to turn OFF the digest
    }
    byte[] result = new byte[1024];
    result = md.digest();// md5Result is now the MD5 hash/bits
    String sResult = df4.getMD5String(result);
    md.reset();// reset the digest - erases out MD5 hash
    return sResult;
  }
  

  /*
   * This copies a file but also adds a bogus header of 1024 bytes
   * of junk data PLUS simple byte encryption
   *
   */
  public static void copyFile3(File in, File out) throws Exception {
    FileInputStream fis  = new FileInputStream(in);
    FileOutputStream fos = new FileOutputStream(out);
    /* ------------------------------------------------ *
     * 25 OCT                                           *
     * -------------------------------------------------*/
    JFrame parentComponent = new JFrame();
    //parentComponent.setSize(50,50);
    //parentComponent.show();
    String MD5 = new String();
    MessageDigest md = MessageDigest.getInstance("MD5");
    DigestInputStream dis = new DigestInputStream(
                                  fis,
                                  md);
    double inLen = in.length();// length of file in bytes
    double inKLen = (inLen / 1024);// total kilobytes
    double inRemainder = inLen - (inKLen * 1024);// last block of bytes
    String sDisplay = new String("Processing...");
    int iBlocksRead = 0;// how many 1k blocks read?
    ProgressMonitor pm = new ProgressMonitor(parentComponent,
                                             null,
                                             sDisplay,
                                             0,
                                             (int) inKLen);
    // pm.setMillisToPopup(1000);// 1 second
    /* ------------------------------------------------ *
     * END 25 OCT                                       *
     * -------------------------------------------------*/

    try {
        byte[] buf = new byte[1024];
        byte[] myheader = new byte[1024];// bogus header of Junk Data
        Random generator = new Random(19580427);
        int r = 0;
        for(int i=0;i<1024;i++){
            // r = generator.nextInt(26);// rand 1-26 (letters)
            r = (int) (Math.random() * 26);
            myheader[i]=(byte) (65+r);// 90 == Z
        }
        fos.write(myheader,0,1024);// write the bogus header
        int j=1024;
        long iBytes = in.length();// bytes
        if(iBytes>=1000000){
          System.out.println("Encrypting " + (iBytes/1000000) + " mb. This could take awhile. Please stand by...");
        }else{
          System.out.println("Encrypting " + iBytes + " bytes. Please stand by...");
        }
        //while ((j = fis.read(buf)) != -1) {
        while ((j = dis.read(buf)) != -1) {
            // simple encrypt the buffer
            for(int ii=0;ii<1024;ii++) buf[ii]+=128;// Rot-13 - call again to debug
            fos.write(buf, 0, j);// start offset after junk header
            /* ------------------------------------------------ *
             * 25 OCT                                           *
             * -------------------------------------------------*/
            if(pm.isCanceled()) throw new java.lang.Exception("User cancelled file i/o operation");
            iBlocksRead++;
            pm.setProgress(iBlocksRead);
            /* ------------------------------------------------ *
             * END 25 OCT                                       *
             * -------------------------------------------------*/
        }
        System.out.println("Done!");
       /* ------------------------------------------------ *
        * 25 OCT                                           *
        * -------------------------------------------------*/
        pm.setProgress((int)inKLen);// reached end of progress meter
        byte[] result = new byte[1024];
        result = md.digest();// md5Result is now the MD5 hash/bits
        String sResult = df4.getMD5String(result);
        md.reset();// reset the digest - erases out MD5 hash
        System.out.println("MD5 result==" + sResult);
       /* ------------------------------------------------ *
        * END 25 OCT                                       *
        * -------------------------------------------------*/
    } 
    catch (Exception e) {
        throw e;
    }
    finally {
        if (fis != null) fis.close();
        if (fos != null) fos.close();
        if (dis != null) dis.close();
       /* ------------------------------------------------ *
        * 25 OCT                                           *
        * -------------------------------------------------*/
        parentComponent.dispose();// destroy the JFrame
       /* ------------------------------------------------ *
        * END 25 OCT                                       *
        * -------------------------------------------------*/
    }

  }


  public static void uncopyFile3(File in, File out) throws Exception {
    FileInputStream fis  = new FileInputStream(in);
    FileOutputStream fos = new FileOutputStream(out);
    /* ------------------------------------------------ *
     * 25 OCT                                           *
     * -------------------------------------------------*/
    JFrame parentComponent = new JFrame();
    String MD5 = new String();
    MessageDigest md = MessageDigest.getInstance("MD5");
    DigestOutputStream dos = new DigestOutputStream(
                                  fos,
                                  md);
    double inLen = in.length();// length of file in bytes
    double inKLen = (inLen / 1024);// total kilobytes
    double inRemainder = inLen - (inKLen * 1024);// last block of bytes
    String sDisplay = new String("Processing...");
    int iBlocksRead = 0;// how many 1k blocks read?
    ProgressMonitor pm = new ProgressMonitor(parentComponent,
                                             null,
                                             sDisplay,
                                             0,
                                             (int) inKLen);
    /* ------------------------------------------------ *
     * END 25 OCT                                       *
     * -------------------------------------------------*/
    try {
        byte[] buf = new byte[1024];
        byte[] myheader = new byte[1024];// bogus header of Z's
        for(int i=0;i<1024;i++) myheader[i]=90;
        fis.read(myheader,0,1024);// read the bogus header
        int j=1024;
        while ((j = fis.read(buf)) != -1) {
            // simple de-crypt the buffer
            for(int ii=0;ii<1024;ii++){
              buf[ii]=(byte) (buf[ii]+128);
            }
            // fos.write(buf, 0, j);// start offset after junk header
            dos.write(buf, 0, j);
            /* ------------------------------------------------ *
             * 25 OCT                                           *
             * -------------------------------------------------*/
            if(pm.isCanceled()) throw new java.lang.Exception("User cancelled file i/o operation");
            iBlocksRead++;
            pm.setProgress(iBlocksRead);
            /* ------------------------------------------------ *
             * END 25 OCT                                       *
             * -------------------------------------------------*/
        }
        System.out.println("Done!");
       /* ------------------------------------------------ *
        * 25 OCT                                           *
        * -------------------------------------------------*/
        pm.setProgress((int)inKLen);// reached end of progress meter
        byte[] result = new byte[1024];
        result = md.digest();// md5Result is now the MD5 hash/bits
        String sResult = df4.getMD5String(result);
        md.reset();// reset the digest - erases out MD5 hash
        System.out.println("MD5 result==" + sResult);
       /* ------------------------------------------------ *
        * END 25 OCT                                       *
        * -------------------------------------------------*/

    } 
    catch (Exception e) {
        throw e;
    }
    finally {
        if (fis != null) fis.close();
        if (fos != null) fos.close();
        if (dos != null) dos.close();
       /* ------------------------------------------------ *
        * 25 OCT                                           *
        * -------------------------------------------------*/
        parentComponent.dispose();// destroy the JFrame
       /* ------------------------------------------------ *
        * END 25 OCT                                       *
        * -------------------------------------------------*/

    }

  }


// More obfuscation stuff...
//
//  public long getPayroll(int x) {  }    -->    abc
//  public long getPayroll() { }          -->    xyz
//  public long saveState(int x) {  }     -->    xyz
//  public long getDate() { }             -->    abc 

// Data storage obfuscation affects how data is stored in memory. example:
//
// Before:
//       int i = 1;
//       while (i < 1000) {
//            ... A[I] ...;
//            i ++;
//       }
// 
// After:
//       int i=11;
//       while (i < 8003) {
//       ... A[(i-3)/8] ...;
//       i += 8;
//       }

/*  ********************************
Data aggregation obfuscation alters how data is grouped together. For example, a two-dimensional array can be converted into a one-dimensional array and vice-versa.

Data ordering obfuscation changes how data is ordered. For example, an array used to store a list of integers usually has the ith element in the list at position i in the array. Instead, we could use a function f(i) to determine the position of the ith element in the list.

Control Obfuscation
The idea here is to disguise the real control flow in a program.

Control aggregation obfuscation changes the way in which program statements are grouped together. For example, it is possible to inline procedures. That is, replacing a procedure call with the statements from the called procedure itself.

Control ordering obfuscation alters the order in which statements are executed. For example, loops can be made to iterate backwards instead of forwards. 

Control computation obfuscation affects the control flow in a program. These can be divided up further:

"Smoke and mirrors" obfuscation hides the real control flow behind irrelevant statements. For example, code that will never be executed can be inserted (dead code). 
High-level language breaking obfuscation introduces features at the object code level that have no direct source code equivalent. Java has no goto statement, and thus cannot represent non-reducible control flow graphs [1]. However there is a Java bytecode goto instruction, so Java bytecodes can represent non-reducible control flow graphs. For example, inserting a jump into the middle of a while-loop creates a non-reducible control flow graph that cannot be transformed back into a standard while-loop without difficulty. 
Control flow abstraction is essentially the inverse of the task that a compiler performs. An example of altering control flow abstraction would be to find a sequence of low-level instructions that are equivalent to a while-loop and then add redundant termination conditions to the loop. The loops both terminate when i equal 1000. i is not divisible by 1000 for all values that i takes on in the loop, namely for 1 <= i < 1000. 

Before

int i = 1;
while (i < 1000) {
...
i ++;
}



After
  
 int i = 1;
while ((i < 1000) || (i % 1000 == 0)) {
...
i ++;
}
 
************************************* */



  // JDK 1.4+ using the java.nio package (faster)
//  public static void copyFile(File in, File out) 
//        throws IOException 
//    {
//        FileChannel inChannel = new
//            FileInputStream(in).getChannel();
//        FileChannel outChannel = new
//            FileOutputStream(out).getChannel();
//        try {
//            inChannel.transferTo(0, inChannel.size(),
//                    outChannel);
//        } 
//        catch (IOException e) {
//            throw e;
//        }
//        finally {
//            if (inChannel != null) inChannel.close();
//            if (outChannel != null) outChannel.close();
//        }
//    }


// Even better 1.4 way (using 64MB-32Kb)...
// public static void copyFile(File in, File out) 
//        throws IOException 
//    {
//        FileChannel inChannel = new
//            FileInputStream(in).getChannel();
//        FileChannel outChannel = new
//            FileOutputStream(out).getChannel();
//        try {
//           // magic number for Windows, 64Mb - 32Kb)
//           int maxCount = (64 * 1024 * 1024) - (32 * 1024);
//           long size = inChannel.size();
//           long position = 0;
//           while (position < size) {
//              position += 
//                inChannel.transferTo(position, maxCount, outChannel);
//        } 
//        catch (IOException e) {
//            throw e;
//        }
//        finally {
//            if (inChannel != null) inChannel.close();
//            if (outChannel != null) outChannel.close();
//        }
//    }
//
//    public static void main(String args[]) throws IOException{
//        FileUtils.copyFile(new File(args[0]),new File(args[1]));
//  }








  // old - pre JDK 1.4
  public static void copyFileOLD(File in, File out) throws Exception {
    FileInputStream fis  = new FileInputStream(in);
    FileOutputStream fos = new FileOutputStream(out);
    try {
        byte[] buf = new byte[1024];
        int i = 0;
        while ((i = fis.read(buf)) != -1) {
            fos.write(buf, 0, i);
        }
    } 
    catch (Exception e) {
        throw e;
    }
    finally {
        if (fis != null) fis.close();
        if (fos != null) fos.close();
    }
  }
  // Then call this from main...
  //  FileUtils.copyFileOLD(new File(args[0]),new File(args[1]));

    /**
     * Helper function that prints unsigned two character hex digits.
     *  Taken from class:  java.awt.security.MessageDigest
     */
    private static void hexDigit(PrintStream p, byte x) {
	char c;
	
	c = (char) ((x >> 4) & 0xf);
	if (c > 9) {
	    c = (char) ((c - 10) + 'a');
	} else {
	    c = (char) (c + '0');
	}
	p.write(c);

	c = (char) (x & 0xf);
	if (c > 9) {
	    c = (char)((c - 10) + 'a');
	} else {
	    c = (char)(c + '0');
	}
	p.write(c);
    }

   // gets the MD5 hex string 
   public static String getMD5String(byte[] b) {
	ByteArrayOutputStream ou = new ByteArrayOutputStream();
	PrintStream p = new PrintStream(ou);
		
        // p.print(this.getClass().getName()+" Message Digest ");
        if (b != null) {
            // p.print("<");
            for(int i = 0; i < b.length; i++)
                hexDigit(p, b[i]);
            // p.print(">");
	} else {
	    p.print("<incomplete>");
	}
	p.println();
	return (ou.toString());
    }
 

}
