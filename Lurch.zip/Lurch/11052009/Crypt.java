
 /*
 * Description: A java Object that attempts to encrypt an input file <code>infile</code>
 *              using java.lang.String <code>password</code> and send to an output file <code>outfile</code>.
 *              Use this from the command prompt, not within an applet, to encrypt your files for use
 *              with the <code>ReadText.class</code>.
 * 
 *              Example: Take a plaintext file myfile.txt and encrypt it to new file mynewfile.txt using
 *              password "cryptology": 
 *              1. Assuming you are using the JDK1.1 developer's kit, from the command prompt type: 
 *                       java Crypt myfile.txt mynewfile.txt cryptology
 * 
 * Requires: StringManipulator.class            
 *              
 * Creation date: (4/10/2000 07:00:00 AM)
 *
 * @author: Bill Chelonis
 *
 * Author Email:   bill_chelonis@americancentury.com
 */

import java.io.*;

public class Crypt {
  /**
  * Description: Method <code>main</code> is used to run this java application from the command prompt.
  * Creation date: (4/10/2000 07:00:00 AM)
  * @return void
  * @param args java.lang.String[]
  */
  public static void main(java.lang.String[] args) {
     try{
       runMe(args[0],args[1],args[2]);
       }catch(java.lang.ArrayIndexOutOfBoundsException err){
           System.out.println("To encrypt, syntax is:  java Crypt <infile> <outfile> <password>");
       }catch(Exception eee){

       }       
  }

  /**
  * Description: Method <code>runMe</code> is used to take from java.lang.String <code>infile</code>
  *              and use java.lang.String <code>password</code> to send data encrypted to 
  *              java.lang.String <code>outfile</code>.
  *
  * Creation date: (4/10/2000 07:00:00 AM)
  * @return int
  * @param infile java.lang.String,outfile java.lang.String,password java.lang.String
  */
  public static int runMe(java.lang.String infile,java.lang.String outfile,java.lang.String password) throws Exception{
     String text=null;
     // added 5NOV2009
     DataInputStream stream = new DataInputStream(new FileInputStream(infile));
     DataOutputStream dos = new DataOutputStream(new FileOutputStream(outfile));

     try{
       // stream and dos were initiated here before - changed to above on 5NOV
       do {
         text = stream.readLine();
         if (text!=null){
           dos.writeBytes(StringManipulator.keyRot(text,password,1) + "\r\n");
         }
       }while (text!=null);
      }catch(Exception e){
      }finally{
         // added 5NOV2009
         if(stream!=null) stream.close();
         if(dos!=null) dos.close();
      }
    System.out.println("Infile: " + infile + "  Outfile: " + outfile + " . . . encryption done!");
    return 0;
  }
}



