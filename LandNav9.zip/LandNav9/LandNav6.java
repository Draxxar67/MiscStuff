import java.awt.*;
import javax.swing.*;
import java.applet.*;
import java.awt.event.*;
import java.awt.image.*; // for bufferedimage
import java.awt.geom.*;// AffineTransform;

/*
 *      True isometric lines are rendered at 26.565 degrees,
 *      but 30 degrees is often used instead.
 *
 */

public class LandNav6 extends Applet implements MouseMotionListener,
        MouseListener {

         Graphics2D bufferGraphics;
         Image offscreen;
         MediaTracker tracker;
         Dimension dim;

         Rectangle cameraWindow;

         Point playerLocation = new Point(0,0);// reset by mouse movement - 571,510);// 25,300);// (571,510);

         /*
          *      Number of pixels wide and high per tile (image ultimately)
          */
         public static final int TILE_PIXEL_WIDTH = 20;// 5;// 20
         public static final int TILE_PIXEL_HEIGHT= 20;// 5;// 20
         /*
          *      Number of rows and columns per "zone" full of tiles.
          *
          *      NOTE: Keep in mind that zones upwards of 300x300
          *      tiles eat up a TON of memory. So keep the zones
          *      relatively small and "scan ahead" to load in other
          *      neighboring zones (a.k.a. WoW and Asheron's Call style)
          *      vs. loading in one huge (laggy) zone, which is EverQuest
          *      style.
          */
         public static final int ZONE_TILES_WIDE = 20;// 30;// 300;//40;// 20
         public static final int ZONE_TILES_HIGH = 30;// 30;// 300;//30;// 30
         /*
          *      How many tiles wide and high is the camera window?
          */
         public static final int CAMERA_WINDOW_TILES_WIDE = 5;// 10;// 4
         public static final int CAMERA_WINDOW_TILES_HIGH = 5;// 10;// 4

         /*
          *      The HUD - Head Up Display
          *                The HUD height is CAMERA_WINDOW_TILES_HIGH  and
          *                the width is CAMERA_WINDOW_TILES_WIDE.
          */
         public static final int HUD_OFFSET_X = (ZONE_TILES_WIDE * TILE_PIXEL_WIDTH);
         public static final int HUD_OFFSET_Y = 0;
         /*
          *      HUD location (top-left corner)
          */
         public static final int HUD_X = HUD_OFFSET_X + 50;
         public static final int HUD_Y = HUD_OFFSET_Y + 10;
         public static final int HUD_CELL_WIDTH = TILE_PIXEL_WIDTH * 4;
         public static final int HUD_CELL_HEIGHT = TILE_PIXEL_HEIGHT * 4;

         private Insets frameInsets;
         
         /*
          *      For production, suggested image/tile size of 200x200 pixels.
          */
         public static Rectangle[][] myRects = new Rectangle[ZONE_TILES_WIDE]
                 [ZONE_TILES_HIGH];

         public static int[][] myTileData = new int[ZONE_TILES_WIDE]
                 [ZONE_TILES_HIGH];

         public void moveCameraWindowToPlayerLoc(){
                Point pp1 = getCameraOffsetPoint();
                int newX = (int) pp1.getX();
                int newY = (int) pp1.getY();
                cameraWindow.setLocation((int) playerLocation.getX(),
                                         (int) playerLocation.getY());
                cameraWindow.translate(newX,newY);// move from 0x0
         }

         public Point getCameraOffsetPoint(){
                int newX = (int) playerLocation.getX() -
                           ((int) cameraWindow.getWidth() / 2);
                int newY = (int) playerLocation.getY() -
                           ((int) cameraWindow.getHeight() /2 );  
                Point retPoint = new Point(newX,newY);
                return retPoint;
         }

         public void resetCameraWindowToOrigin(){
              dim = getSize();
              cameraWindow = new Rectangle(0,0,dim.width,dim.height);
         }


         public Image rotateImage(Image sendImage,float angle,float scale){
                 addNotify();
                 frameInsets = getInsets();
                 // inputImage = Toolkit.getDefaultToolkit().getImage(imageFile);

                 BufferedImage sourceBI = new BufferedImage(sendImage.getWidth(null),
                                                            sendImage.getHeight(null),
                                                            BufferedImage.TYPE_INT_ARGB);

                 Graphics2D g = (Graphics2D) sourceBI.getGraphics();
                 g.drawImage(sendImage, 0, 0, null);

                 AffineTransform at = new AffineTransform();

                 // scale image
                 if(scale > 0.0){
                         at.scale(scale,scale);
                 }

                 // rotate 45 degrees around image center
                 at.rotate(angle * Math.PI / 180.0, sourceBI.getWidth() / scale, sourceBI.getHeight() / scale);

    /*
     * translate to make sure the rotation doesn't cut off any image data
     */
    AffineTransform translationTransform;
    translationTransform = findTranslation(at, sourceBI);
    at.preConcatenate(translationTransform);

    // instantiate and apply affine transformation filter
    BufferedImageOp bio;
    bio = new AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR);

    BufferedImage destinationBI = bio.filter(sourceBI, null);

    int frameInsetsHorizontal = frameInsets.right + frameInsets.left;
    int frameInsetsVertical = frameInsets.top + frameInsets.bottom;
    setSize(destinationBI.getWidth() + frameInsetsHorizontal, destinationBI
        .getHeight()
        + frameInsetsVertical);
    // show();
    return (Image) destinationBI;
  }


         public void init(){

              addMouseMotionListener(this);
              addMouseListener(this);

              dim = getSize();
              setBackground(Color.black);
              offscreen = createImage(dim.width,dim.height);
              bufferGraphics = (Graphics2D) offscreen.getGraphics();
              tracker = new MediaTracker(this);

              /*
               *      For initialization we'll setup the camera at the
               *      zone's point of origin (0x0) but the camera window
               *      will be located usually based on where the player is.
               */
              cameraWindow = new Rectangle(0,0,
                      CAMERA_WINDOW_TILES_WIDE * TILE_PIXEL_WIDTH,
                      CAMERA_WINDOW_TILES_HIGH * TILE_PIXEL_HEIGHT);

              /*
               *      Set up the tile data - optional step 
               */
              for(int xx = 0;xx < ZONE_TILES_WIDE;xx++){
                      for(int yy=0;yy < ZONE_TILES_HIGH;yy++){
                              myTileData[xx][yy]=0;
                      }
              }

         }


         public static void main(String[] args){
               JFrame appletWindow = new JFrame("Applet Window");
               LandNav6 meep = new LandNav6();
               meep.setSize(800,800);
               appletWindow.getContentPane().add(meep);
               appletWindow.setSize(850,850);// 680,520);
               appletWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
               appletWindow.setVisible(true);
               meep.init();
         }


    public void update(Graphics g){  paint(g); }


    public void paint(Graphics g) {
        if(tracker==null) return;
        if((tracker.statusAll(false) & MediaTracker.ERRORED) != 0){
               bufferGraphics.setColor(Color.red);
               bufferGraphics.fillRect(0, 0, getSize().width, getSize().height);
               g.drawImage(offscreen,0,0,this);
               return;
        }

        bufferGraphics.clearRect(0,0,dim.width,dim.width);

        bufferGraphics.setColor(Color.red);

        /*
         * Draw whatever here - bufferGraphics.draw... 
         */


         /*
          *      Ultimately you would loop through a vector of
          *      objects in the Zone object, testing if the
          *      cameraWindow contains that object's location Point
          *      and then render accordingly. Trick is... how much
          *      data should you store in each "zone"? Or should we
          *      be using micro-zones to make the for-loop faster?
          *      It is most likely that games such as WoW and Asheron's
          *      Call used micro-zones to make it seem like the zone
          *      never ended (or loaded faster than purely EverQuest style
          *      zones which loaded in a ton of data after crossing each
          *      zone-line into another zone). 
          */
         for(int xx = 0;xx < ZONE_TILES_WIDE;xx++){
                 for(int yy=0;yy < ZONE_TILES_HIGH;yy++){
                         bufferGraphics.setColor(Color.red);
                         bufferGraphics.drawRect(xx * TILE_PIXEL_WIDTH,
                                 yy * TILE_PIXEL_HEIGHT,
                                 TILE_PIXEL_WIDTH,
                                 TILE_PIXEL_HEIGHT);
                         if(myTileData[xx][yy]==1){
                                 bufferGraphics.setColor(Color.green);
                                 bufferGraphics.fillRect(xx * TILE_PIXEL_WIDTH,
                                         yy * TILE_PIXEL_HEIGHT,
                                         TILE_PIXEL_WIDTH,
                                         TILE_PIXEL_HEIGHT);
                         }
                 }
         }

         bufferGraphics.setColor(Color.red);

           cameraWindow.setLocation((int) playerLocation.getX() -
                   ((int) cameraWindow.getWidth() / 2),
                   (int) playerLocation.getY() -
                   ((int) cameraWindow.getHeight() / 2));
           /*
            *      OoverBounds Rectangle. Used for determining what
            *      grids/Images to draw which may start outside the
            *      visible cameraWindow rectangle.
            */
           Rectangle OoverBounds = new Rectangle(
                   (int) cameraWindow.getX() - TILE_PIXEL_WIDTH,
                   (int) cameraWindow.getY() - TILE_PIXEL_HEIGHT,
                   (int) cameraWindow.getWidth() + (TILE_PIXEL_WIDTH * 2),
                   (int) cameraWindow.getHeight() + (TILE_PIXEL_HEIGHT * 2) );


           /*
            *      Here we get the playerLocation as represented in
            *      array cell(tile) coords not literal Zone-X-Y coords.
            *      This will be used to draw the HUD, render images, and
            *      other things. 
            */
           int pX = (int) playerLocation.getX() / TILE_PIXEL_WIDTH;
           int pY = (int) playerLocation.getY() / TILE_PIXEL_HEIGHT;

           System.out.println("___________________");
           int dodo = 0;

        /*      
         *      Here we divide by pixel width or height to get an
         *      exact playerLocation X and Y array value. Then,
         *      to get precision we multiply by pixel width or height
         *      and this all handles the rounding issue, giving us
         *      an exact cell rendered in the array where the mouse is
         *      (i.e. the playerLocation)
         */
        pX = (int) playerLocation.getX() / TILE_PIXEL_WIDTH;
        pY = (int) playerLocation.getY() / TILE_PIXEL_HEIGHT;
        int pxAdjusted = (int) pX * TILE_PIXEL_WIDTH;
        int pyAdjusted = (int) pY * TILE_PIXEL_WIDTH;
        int startGridX = pX - (CAMERA_WINDOW_TILES_WIDE / 2) - 1;
        int startGridY = pY - (CAMERA_WINDOW_TILES_HIGH / 2) - 1;
        int endGridX = pX + (CAMERA_WINDOW_TILES_WIDE / 2) + 1;
        int endGridY = pY + (CAMERA_WINDOW_TILES_WIDE / 2) + 1;
        int tallyX = 0;
        int tallyY = 0;
        int rowLength = CAMERA_WINDOW_TILES_WIDE + 2;
        int colHeight = CAMERA_WINDOW_TILES_HIGH + 2;

        for(int xx = startGridX; xx < endGridX; xx++){
                for(int yy = startGridY; yy < endGridY; yy++){
                        /*
                         *      Check array out of bounds
                         */
                   //     if((xx <= ZONE_TILES_WIDE) &&
                   //       (yy <= ZONE_TILES_HIGH) &&
                   //       (xx >= 0) &&
                   //       (yy >= 0)){
                                        /*
                                         *      Do something...
                                         */
                                        bufferGraphics.setColor(Color.blue);
                                try{

                                        bufferGraphics.drawRect(450 +
                                                (tallyX * TILE_PIXEL_WIDTH),
                                                (tallyY * TILE_PIXEL_HEIGHT),
                                                TILE_PIXEL_WIDTH,
                                                TILE_PIXEL_HEIGHT);
                                        tallyX++;
                                }catch(ArrayIndexOutOfBoundsException aiei){
                                        tallyX = 0;
                                        tallyY ++;
                                        if(tallyY > colHeight) tallyY = 0;
                                }
                                
                                        if(tallyX > rowLength){
                                                tallyX = 0;
                                                tallyY++;
                                                if(tallyY > colHeight){
                                                        tallyY=0;// should never reach this
                                                }
                                        }
                     //   }
                }
        }



           for(int xx = 0;xx < ZONE_TILES_WIDE;xx++){
            for(int yy=0;yy < ZONE_TILES_HIGH;yy++){
               Rectangle TtempRect = new Rectangle(xx * (TILE_PIXEL_WIDTH),
                       yy * (TILE_PIXEL_HEIGHT),
                       TILE_PIXEL_WIDTH,
                       TILE_PIXEL_HEIGHT);
               if(OoverBounds.contains(TtempRect)){
                       bufferGraphics.setColor(Color.orange);

                       bufferGraphics.drawRect(xx * TILE_PIXEL_WIDTH,
                               yy * TILE_PIXEL_HEIGHT,
                               TILE_PIXEL_WIDTH,
                               TILE_PIXEL_HEIGHT);
                       /*
                        *      Calculate difference from current row, col
                        *      to the playerLocation(i.e. mouse pointer).
                        *      And this is the offset number to use to render
                        *      the cell in the HUD...
                        *
                        *      Dist. from top left corner of first cell
                        *      to the mouse pointer is the difference...
                        */

                       int diff1 = xx - pX;
                       int diff2 = yy - pY;
                       if(dodo==0){
                          System.out.println("diff1: "+ diff1 + " diff2: " + diff2);
                          int tXX = (int) (cameraWindow.getX() / TILE_PIXEL_WIDTH);
                          int tYY = (int) (cameraWindow.getY() / TILE_PIXEL_HEIGHT);
                          tXX = (int) ((tXX * TILE_PIXEL_WIDTH) - cameraWindow.getX());
                          tYY = (int) ((tYY * TILE_PIXEL_HEIGHT) - cameraWindow.getY());
                          /*
                           *      This is the actual pixel offset of where the topleft
                           *      corner of the cameraWindow is located.
                           *
                           *      Use this offset plus or minus cells away from player
                           *      location cell to determine where to begin rendering
                           *      images, etc.
                           */
                          System.out.println("cam top-left point: " + tXX + ", " + tYY);
                          dodo = 1;
                       }
                        bufferGraphics.drawRect((pX * HUD_CELL_WIDTH) +
                                                 HUD_OFFSET_X,
                                                (pY * HUD_CELL_HEIGHT) +
                                                 HUD_OFFSET_Y,
                                                 HUD_CELL_WIDTH,
                                                 HUD_CELL_HEIGHT);

               }

            }          
           }

        /*      
         *      Here we divide by pixel width or height to get an
         *      exact playerLocation X and Y array value. Then,
         *      to get precision we multiply by pixel width or height
         *      and this all handles the rounding issue, giving us
         *      an exact cell rendered in the array where the mouse is
         *      (i.e. the playerLocation)
         */
        pX = (int) playerLocation.getX() / TILE_PIXEL_WIDTH;
        pY = (int) playerLocation.getY() / TILE_PIXEL_HEIGHT;
        /*      
         *      Note: re-multiplying (below) after the above division
         *      is no mistake. If we did not do this you would get the
         *      exact player location coordinate but not get the exact
         *      cell coordinate (top-left corner of the grid cell containing
         *      the mouse pointer).
         */
        bufferGraphics.setColor(Color.blue);
        bufferGraphics.drawRect(pX * TILE_PIXEL_WIDTH,
                                pY * TILE_PIXEL_HEIGHT,
                                TILE_PIXEL_WIDTH,
                                TILE_PIXEL_HEIGHT);

        bufferGraphics.setColor(Color.green);
        bufferGraphics.drawRect((int) cameraWindow.getX(),
                                (int) cameraWindow.getY(),
                                (int) cameraWindow.getWidth(),
                                (int) cameraWindow.getHeight());



        
         /*
          *      The HUD - heads up display
          */
         bufferGraphics.drawRect(HUD_X,
                                 HUD_Y,
                                 CAMERA_WINDOW_TILES_WIDE * HUD_CELL_WIDTH,
                                 CAMERA_WINDOW_TILES_HIGH * HUD_CELL_HEIGHT);



        /*
         * Show offscreen image here
         */
        g.drawImage(offscreen,0,0,this);

   

    }

  /*
   * find proper translations to keep rotated image correctly displayed
   */
  private AffineTransform findTranslation(AffineTransform at, BufferedImage bi) {
    Point2D p2din, p2dout;

    p2din = new Point2D.Double(0.0, 0.0);
    p2dout = at.transform(p2din, null);
    double ytrans = p2dout.getY();

    p2din = new Point2D.Double(0, bi.getHeight());
    p2dout = at.transform(p2din, null);
    double xtrans = p2dout.getX();

    AffineTransform tat = new AffineTransform();
    tat.translate(-xtrans, -ytrans);
    return tat;
  }


    public void mouseDragged(MouseEvent e){ }

    public void mouseMoved(MouseEvent e){
             playerLocation.setLocation((int) e.getX(),(int) e.getY());
             repaint();
    }
   

    /**
     * Invoked when the mouse button has been clicked (pressed
     * and released) on a component.
     */
    public void mouseClicked(MouseEvent e){
            /*
             *        Toggle data in current playerLocation
             */
            int pX = (int) playerLocation.getX() / TILE_PIXEL_WIDTH;
            int pY = (int) playerLocation.getY() / TILE_PIXEL_HEIGHT;
            if(pX < 0) pX = -1;
            if(pX >= ZONE_TILES_WIDE) pX = -1;
            if(pY < 0) pY = -1;
            if(pY >= ZONE_TILES_HIGH) pY = -1;
            int pZ = 0;
            if((pX != -1) && (pY != -1)){
                    int errored = 0;
                    try{
                            pZ = myTileData[pX][pY];
                            if(pZ == 0){
                                    pZ = 1;
                            }else{
                                    pZ = 0;
                            }
                            myTileData[pX][pY] = pZ;
                            repaint();
                    }catch(ArrayIndexOutOfBoundsException aie){
                            System.out.println(
                                    "Array out of bounds error: pX == " + pX +
                                    " pY == " + pY +
                                    " Array X == " + ZONE_TILES_WIDE +
                                    " Array Y == " + ZONE_TILES_HIGH + " !");
                    }
            }
    }

    /**
     * Invoked when a mouse button has been pressed on a component.
     */
    public void mousePressed(MouseEvent e){ }

    /**
     * Invoked when a mouse button has been released on a component.
     */
    public void mouseReleased(MouseEvent e){ }

    /**
     * Invoked when the mouse enters a component.
     */
    public void mouseEntered(MouseEvent e){ }

    /**
     * Invoked when the mouse exits a component.
     */
    public void mouseExited(MouseEvent e){ }


}
