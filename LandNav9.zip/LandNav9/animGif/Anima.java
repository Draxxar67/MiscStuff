import java.awt.*;
import java.net.*;
import javax.swing.*;
// import java.awt.*;
import java.awt.event.*;
// import javax.swing.*;
import java.applet.*;
import java.net.URL;
import java.awt.event.*;
import java.awt.image.*; // for bufferedimage
import java.awt.geom.*;// AffineTransform;

/*
 *      Tests Java's support of animated GIFs.
 *
 */ 
public class Anima {
    public static void main(String[] args) throws MalformedURLException {

        // URL url = new URL("c:\data\jdk2\bin\anim1.gif"); // <URL to your Animated GIF>");

 
        JFrame f = new JFrame("Animation");
        Image img1 = f.getToolkit().getImage("anim1.gif");
        // Icon icon = new ImageIcon(url);
        Icon icon = new ImageIcon(img1,"an animated gif example");
        JLabel label = new JLabel(icon);
        f.getContentPane().add(label);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);

    }
}
