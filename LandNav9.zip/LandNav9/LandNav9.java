// package emexifomy;           

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.applet.*;
import java.net.URL;
import java.awt.event.*;
import java.awt.image.*; // for bufferedimage
import java.awt.geom.*;// AffineTransform;


/*
 *
 *      To request Applet focus automatically in a web page put this
 *      in the head of your HTML:
 *              <script type="text/javascript">
 *                      onload = function(){
 *                              document.getElementsByTagName( "applet" )[0].focus();
 *                      }
 *              </script>
 */

/*
 *      True isometric lines are rendered at 26.565 degrees,
 *      but 30 degrees is often used instead.
 *
 */

public class LandNav9 extends JApplet implements KeyListener {

         Graphics2D bufferGraphics;
         Image offscreen;
         MediaTracker tracker;
         Dimension dim;
         public static Boolean isApplication = Boolean.FALSE;// set to true if void main is run from command line
         /*
          *  Move Speeds (in pixels per turn):
          *  0 is root              12 is run            75 is GM
          *  1-3 are snares         35 is horse
          *  5 is walk              50 is bard
          */
         public static int player_speed = 5;
         public static java.awt.image.BufferedImage playerImage;
         public static float playerRotationAngle = 360f;// rotation angle
         public static int scrollX = 128;// player world pixel location X 
         public static int scrollY = 128;// player world pixel location Y
         // looks okay... but could be better...
         public static Rectangle playerMovePointer = new Rectangle(384 - 20, 384 - 20, 5,100);    //  le(scrollX,scrollY,5,100);


         public static final boolean DEBUG = true;// true or false
         public static final int TILE_SIZE = 128; // System.size = how big each SQUARE tile is - NOTE: image is this size (128x128 pixels! anything else returns an error)
         public static final int MAIN_OFFSET[] = { 0,128,256,384,512,640,768,896,1024,1152,1280,1408,1536,1664,1792,1920,2048 };// vs. calculating x or y * TILE_SIZE in graphics drawing rotine every time


         /*
          *        ZONE_WIDTH and HEIGHT (depth) is how many
          *        tiles, not pixels, deep and wide the
          *        zone is.
          */
         public static final int ZONE_WIDTH = 16;
         public static final int ZONE_HEIGHT = 16;

         // public static int mapData[][] = new mapData[16][32];
         public static int mapData[][] =  {
                      {2,2,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0},
                      {2,2,0,1,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0},
                      {2,0,0,1,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0},
                      {1,2,0,1,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0},
                      {1,2,2,1,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0},
                      {1,2,2,1,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0},
                      {1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0},
                      {1,2,2,1,2,2,1,1,1,1,1,2,2,2,2,1,0,0,0,0,0},
                      {1,2,1,1,2,2,1,0,0,0,1,2,2,2,2,1,0,0,0,0,0},
                      {1,2,1,1,2,2,1,0,0,0,1,2,2,2,2,1,0,0,0,0,0},
                      {1,2,1,1,2,2,1,0,0,0,1,2,2,2,2,1,0,0,0,0,0},
                      {1,2,1,1,2,2,1,1,1,1,1,2,2,2,2,1,0,0,0,0,0},
                      {1,2,1,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
                      {1,2,2,1,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0},
                      {1,2,2,1,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0},
                      {1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,1,0,0,0,0,0},
                      {1,1,1,2,1,1,1,1,1,1,1,1,1,2,2,1,0,0,0,0,0}, 
                      {0,0,2,2,2,2,0,0,0,0,0,0,0,2,2,0,0,0,0,0,0},
                      {0,0,0,2,2,0,0,0,0,0,0,0,0,2,2,0,0,0,0,0,0},
                      {0,0,0,2,2,0,0,0,0,0,0,0,0,2,2,0,0,0,0,0,0},
                      {0,0,2,2,0,0,0,0,0,0,0,0,0,2,2,0,0,0,0,0,0},
                      {0,2,2,0,0,0,0,0,0,0,0,0,0,2,2,0,0,0,0,0,0}
              };



         public static Image img[];
         public static boolean draw_large_map = false;
         public static int offsetX = 0;// calculated in drawMap routine
         public static int offsetY = 0;



      
         public void init(){
              addKeyListener(this);
              // setSize(800,800);

              dim = getSize();
              setBackground(Color.black);
              offscreen = createImage(dim.width,dim.height);
              bufferGraphics = (Graphics2D) offscreen.getGraphics();

              img = new Image[10];
              /*
               *      getClass().getResource() works in either
               *      applet or application, 1.1 or 1.3, returns URL for file name.
               */
              URL url = getClass().getResource("2.jpg");// applet only version: Image = getImage(getCodeBase(), "t.jpg");
              img[0] = getToolkit().getImage(getClass().getResource("0.jpg"));
              img[1] = getToolkit().getImage(url);   // img[1] = getToolkit().getImage("t.jpg");
              img[2] = getToolkit().getImage(getClass().getResource("1.jpg"));
              // dudly = getToolkit().getImage(getClass().getResource("gumby.gif"));
              java.io.File input = new java.io.File("gumby.gif");
              try{
                      playerImage = javax.imageio.ImageIO.read(input);// getToolkit().getImage(getClass().getResource("gumby.gif"));// ImageIO.read("gumby.gif");
              }catch(java.io.IOException ioe){ System.exit(0); }

              try{
                      tracker = new MediaTracker(this);
                      tracker.addImage(img[0], 0);
                      tracker.addImage(img[1], 1);
                      tracker.addImage(img[2], 2);
                      tracker.addImage(playerImage,3);
                      tracker.waitForID(0);
                      tracker.waitForID(1);
                      tracker.waitForID(2);
                      tracker.waitForID(3);
                      //  tracker.waitForAll();
              }catch(InterruptedException e){ }

              /*
               *      This code is used to set focus in the Applet.
               *      Applets will not accept focus unless the Applet is
               *      first visible, so check and set visible if needed,
               *      then requestFocus() a few times like so...
               */
              if(!isVisible()){
                      setVisible(true);
              }
              requestFocus();
              // requestFocusInWIndow();
              requestFocus();

              

              // myThread = new Thread(this);// where "this" is the Runnable target
              // myThread.setRunning(true);
              // myThread.start();


        }


         public static void main(String[] args){
               JFrame appletWindow = new JFrame("Applet Window");
               LandNav9 meep = new LandNav9();
               /*
                *      Mark that user ran this from command line,
                *      so it is an application, not an applet.
                */
               meep.isApplication = Boolean.TRUE;


               Dimension prefSize = new Dimension(800,800);
               Dimension scrSize = Toolkit.getDefaultToolkit().getScreenSize();
               int finWidth  = scrSize.width;
               int finHeight = scrSize.height;
               Dimension finDims;
               if(finWidth < prefSize.width){
                       finDims = new Dimension(finWidth,finHeight);
               }else{
                       finDims  = prefSize;
                       appletWindow.setLocation((finWidth  - prefSize.width) / 2, (finHeight - prefSize.height) / 2);
               }
               appletWindow.setSize(finDims);

               meep.setSize(800,800);
               appletWindow.setLocation(50,50);

               appletWindow.addWindowListener(new WindowAdapter(){
                       public void windowClosing(WindowEvent e){
                               // dispose();
                               System.exit(0);
                       }
               });
               appletWindow.getContentPane().add(meep);
               appletWindow.setSize(850,850);// 680,520);
               appletWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
               appletWindow.setVisible(true);// show() is deprecated
               meep.init();

               int rowCount = mapData.length;// ZONE_WIDTH
               int colCount = mapData[0].length;// ZONE_HEIGHT
               System.out.println("row: " + rowCount + " col: " + colCount);
               // meep.start();
               // appletWindow.pack();// packing would shrink the applet window to smallest component, eliminating the call to "setSize(850,850)"
         }


    public void update(Graphics g){  paint(g); }


    public void paint(Graphics g) {
        if(tracker==null) return;
        if((tracker.statusAll(false) & MediaTracker.ERRORED) != 0){
               bufferGraphics.setColor(Color.red);
               bufferGraphics.fillRect(0, 0, getSize().width, getSize().height);
               g.drawImage(offscreen,0,0,this);
               return;
        }

        /*
         * Draw whatever here - bufferGraphics.draw... 
         */
         if(draw_large_map){
                 drawMapLarge(g);
         }else{
                 drawMap2(g);
         }


        /*
         * Show offscreen image here (if not already in above routine(s))
         */
        // g.drawImage(offscreen,0,0,this);
    }


    /*
     *      This checks specifically for array out of bounds
     *      to catch it before an error occurs. Faster code
     *      in drawMap2 takes a different approach and lets
     *      errors occur if array index out of bounds but it
     *      is assumed the final program will have "padded"
     *      arrays to avoid going +/- 2 outside the limit.
     */
    public void drawMap(Graphics g){
            bufferGraphics.clearRect(0,0,dim.width,dim.width);

            int playerTileX = (int) scrollX / TILE_SIZE;
            int playerTileY = (int) scrollY / TILE_SIZE;
            
            offsetX = scrollX % TILE_SIZE;// % is a remainder function
            offsetY = scrollY % TILE_SIZE;

            int myImageNbr;
            Image tempImage;
            int relationalX;
            int relationalY;

            /*
             *      Where x,y are the relational coords to the playerX, Y
             *      and where x1,y1 are the display coords for placement of
             *      the images.
             *
             *      Relational Matrix:
             *      -1,-1   -1,0   -1,1
             *       0,-1    0,0    0,1
             *       1,-1    1,0    1,1
             *      .... where 0,0 are the player coordinates
             *
             *      Display Matrix:
             *       1,1     1,2    1,3
             *       2,1     2,2    2,3
             *       3,1     3,2    3,3
             *      .... where any X * image_width and
             *           any Y * image_height should equal placement
             *           coordinates of the top-left of the image in
             *           the display screen.
             *
             *      For effiency we use one set of X,Y loops
             *      and calculate both matrixes at the same time:
             */
             int rowCount = mapData.length;// ZONE_WIDTH
             int colCount = mapData[0].length;// ZONE_HEIGHT
             for(int x = -2, x2= 0;x < 2;x++, x2++){
                   for(int y = -2, y2=0;y < 2;y++, y2++){
                            relationalX = playerTileX + x;// x
                            relationalY = playerTileY + y;// y
                            if((relationalX >= 0) &&
                               (relationalX < rowCount) &&
                               (relationalY >= 0) &&
                               (relationalY < colCount)){
                                    /*
                                     *      1. take Relational Matrix result
                                     *      and find the image from the main
                                     *      zone map image array.
                                     *
                                     *      2. plot the image to the screen
                                     *      based on the player x,y offset
                                     *      value and the result of the Display Matrix
                                     *      multiplied by image height and width.
                                     */
                                    try{
                                            /*
                                             *      These are switched around due to the
                                             *      way in which we are looping through
                                             *      the array. Otherwise you end up with
                                             *      a backwards mirrored zone if you
                                             *      put [relationalX] before [relationalY]
                                             */
                                            myImageNbr = mapData[relationalY][relationalX];// [relationalX][relationalY];
                                    }catch(ArrayIndexOutOfBoundsException aoe){
                                            myImageNbr = 0;// should never happen but just in case
                                    }
                                    if(myImageNbr > 0){
                                            tempImage = (Image) img[myImageNbr];
                                            int ix = (int) (x2 * TILE_SIZE) - offsetX;
                                            int iy = (int) (y2 * TILE_SIZE) - offsetY;
                                            // int ix = (int) (relationalX * TILE_SIZE) - offsetX;
                                            // int iy = (int) (relationalY * TILE_SIZE) - offsetY;
                                            bufferGraphics.drawImage(tempImage, ix, iy, this);
                                    }
                           }
                   }
             }

             bufferGraphics.setColor(Color.red);

             bufferGraphics.drawRect(TILE_SIZE, TILE_SIZE,TILE_SIZE,TILE_SIZE);
             bufferGraphics.drawRect(1, 1,TILE_SIZE * 3,TILE_SIZE * 3);

             /*
              *      Border rectangles drawn over excess graphics to
              *      make things neat
              */
             bufferGraphics.setColor(Color.green);
             bufferGraphics.fillRect(1, TILE_SIZE * 3, TILE_SIZE * 3, TILE_SIZE * 2);
             bufferGraphics.setColor(Color.blue);
             bufferGraphics.fillRect(TILE_SIZE * 3, 1, TILE_SIZE * 2, TILE_SIZE * 5);

            /*
             * Show offscreen image here
             */
             g.drawImage(offscreen,0,0,this);

    }

    /*
     *      This allows array index out of bounds, assuming
     *      the final program will have "padded" zone map arrays
     *      with +/- 2 along the borders. drawMap2 is also faster
     *      than drawMap in that it uses a smaller loop with less
     *      variables and less computation per loop.
     */
    public void drawMap2(Graphics g){
            bufferGraphics.clearRect(0,0,dim.width,dim.width);

            int playerTileX = (int) scrollX / TILE_SIZE;
            int playerTileY = (int) scrollY / TILE_SIZE;
            
            offsetX = scrollX % TILE_SIZE;// % is a remainder function
            offsetY = scrollY % TILE_SIZE;

            int myImageNbr;
            Image tempImage;
            int relationalX;
            int relationalY;

            /*
             *      Where x,y are the relational coords to the playerX, Y
             *      and where x1,y1 are the display coords for placement of
             *      the images.
             *
             *      Relational Matrix:
             *      -1,-1   -1,0   -1,1
             *       0,-1    0,0    0,1
             *       1,-1    1,0    1,1
             *      .... where 0,0 are the player coordinates
             *
             *      Display Matrix:
             *       1,1     1,2    1,3
             *       2,1     2,2    2,3
             *       3,1     3,2    3,3
             *      .... where any X * image_width and
             *           any Y * image_height should equal placement
             *           coordinates of the top-left of the image in
             *           the display screen.
             *
             *      For effiency we use one set of X,Y loops
             *      and calculate both matrixes at the same time:
             */
             int rowCount = mapData.length;// ZONE_WIDTH
             int colCount = mapData[0].length;// ZONE_HEIGHT

             //for(int x = -2, x2= 0;x < 2;x++, x2++){
             //      for(int y = -2, y2=0;y < 2;y++, y2++){
             for(int x=0;x < 5;x++){
                     for(int y = 0;y < 5; y++){
                             relationalX = playerTileX + x - 2;// 2;
                             relationalY = playerTileY + y - 2;// 2;
                             /*
                              *      1. take Relational Matrix result
                              *      and find the image from the main
                              *      zone map image array.
                              *
                              *      2. plot the image to the screen
                              *      based on the player x,y offset
                              *      value and the result of the Display Matrix
                              *      multiplied by image height and width.
                              */
                             try{
                                     /*
                                      *      These are switched around due to the
                                      *      way in which we are looping through
                                      *      the array. Otherwise you end up with
                                      *      a backwards mirrored zone if you
                                      *      put [relationalX] before [relationalY]
                                      */
                                      myImageNbr = mapData[relationalY][relationalX];// [relationalX][relationalY];
                                      tempImage = (Image) img[myImageNbr];
                                      int ix = (int) MAIN_OFFSET[x] - offsetX - 64;
                                      int iy = (int) MAIN_OFFSET[y] - offsetY - 64;
                                      if(tempImage != null)
                                              bufferGraphics.drawImage(tempImage, ix, iy, this);
                             }catch(ArrayIndexOutOfBoundsException aoe){
                                      myImageNbr = 0;// should never happen but just in case
                                      System.out.print(".");
                             }catch(NullPointerException e){
                                      System.out.print("0");
                             }
                     }
             }

             bufferGraphics.setColor(Color.red);

             // bufferGraphics.drawRect(TILE_SIZE, TILE_SIZE,TILE_SIZE,TILE_SIZE);
             bufferGraphics.drawRect(MAIN_OFFSET[1],MAIN_OFFSET[1],TILE_SIZE,TILE_SIZE);
             bufferGraphics.drawRect(1, 1,TILE_SIZE * 3,TILE_SIZE * 3);

             /*
              *      Border rectangles drawn over excess graphics to
              *      make things neat
              */
             bufferGraphics.setColor(Color.green);
             bufferGraphics.fillRect(1, TILE_SIZE * 3, TILE_SIZE * 3, TILE_SIZE * 2);
             bufferGraphics.setColor(Color.blue);
             bufferGraphics.fillRect(TILE_SIZE * 3, 1, TILE_SIZE * 2, TILE_SIZE * 5);

             /*
              *      Check triggers here and
              *      display message, trap graphics, etc.
              */
             checkTriggers();

             
             /*
              * Show offscreen image here
              */
             g.drawImage(offscreen,0,0,this);
              
    }        

    /*
     *      This allows array index out of bounds, assuming
     *      the final program will have "padded" zone map arrays
     *      with +/- 2 along the borders. drawMap2 is also faster
     *      than drawMap in that it uses a smaller loop with less
     *      variables and less computation per loop.
     */
    public void drawMapLarge(Graphics g){
            bufferGraphics.clearRect(0,0,dim.width,dim.width);

            int playerTileX = (int) scrollX / TILE_SIZE;
            int playerTileY = (int) scrollY / TILE_SIZE;
            
            offsetX = scrollX % TILE_SIZE;// % is a remainder function
            offsetY = scrollY % TILE_SIZE;

            int myImageNbr;
            Image tempImage;
            int relationalX;
            int relationalY;

            /*
             *      Where x,y are the relational coords to the playerX, Y
             *      and where x1,y1 are the display coords for placement of
             *      the images.
             *
             *      Relational Matrix:
             *      -1,-1   -1,0   -1,1
             *       0,-1    0,0    0,1
             *       1,-1    1,0    1,1
             *      .... where 0,0 are the player coordinates
             *
             *      Display Matrix:
             *       1,1     1,2    1,3
             *       2,1     2,2    2,3
             *       3,1     3,2    3,3
             *      .... where any X * image_width and
             *           any Y * image_height should equal placement
             *           coordinates of the top-left of the image in
             *           the display screen.
             *
             *      For effiency we use one set of X,Y loops
             *      and calculate both matrixes at the same time:
             */
             int rowCount = mapData.length;// ZONE_WIDTH
             int colCount = mapData[0].length;// ZONE_HEIGHT
             int ix = 0;
             int iy = 0;
             //for(int x = -2, x2= 0;x < 2;x++, x2++){
             //      for(int y = -2, y2=0;y < 2;y++, y2++){
             for(int x=0;x < 8;x++){
                     for(int y = 0;y < 8; y++){
                             relationalX = playerTileX + x - 3;// -4
                             relationalY = playerTileY + y - 3;// -4
                             /*
                              *      1. take Relational Matrix result
                              *      and find the image from the main
                              *      zone map image array.
                              *
                              *      2. plot the image to the screen
                              *      based on the player x,y offset
                              *      value and the result of the Display Matrix
                              *      multiplied by image height and width.
                              */
                             try{
                                     /*
                                      *      These are switched around due to the
                                      *      way in which we are looping through
                                      *      the array. Otherwise you end up with
                                      *      a backwards mirrored zone if you
                                      *      put [relationalX] before [relationalY]
                                      */
                                      myImageNbr = mapData[relationalY][relationalX];// [relationalX][relationalY];
                                      tempImage = (Image) img[myImageNbr];
                                      ix = (int) MAIN_OFFSET[x] - offsetX;
                                      iy = (int) MAIN_OFFSET[y] - offsetY;
                                      if(tempImage != null)
                                              bufferGraphics.drawImage(tempImage, ix, iy, this);
                             }catch(ArrayIndexOutOfBoundsException aoe){
                                      myImageNbr = 0;// should never happen but just in case
                                      System.out.print(".");
                             }catch(NullPointerException e){
                                      System.out.print("0");
                             }
                     }
             }

             bufferGraphics.setColor(Color.red);

             // bufferGraphics.drawRect(TILE_SIZE, TILE_SIZE,TILE_SIZE,TILE_SIZE);
             bufferGraphics.drawRect(MAIN_OFFSET[2] + 64,MAIN_OFFSET[2] + 64,TILE_SIZE,TILE_SIZE);
             bufferGraphics.drawRect(1, 1,MAIN_OFFSET[8],MAIN_OFFSET[8]);

             /*
              *      Border rectangles drawn over excess graphics to
              *      make things neat
              */
             bufferGraphics.setColor(Color.green);
             bufferGraphics.fillRect(1, MAIN_OFFSET[6], MAIN_OFFSET[6], MAIN_OFFSET[4]);
             bufferGraphics.setColor(Color.blue);
             bufferGraphics.fillRect(MAIN_OFFSET[6], 1, MAIN_OFFSET[4], MAIN_OFFSET[10]);

             /*
              *      Rotateimage example
              *
              *      Step 1: Initialize your AffineTransform object
              * 
              */
             java.awt.geom.AffineTransform transform = new AffineTransform();
             /*
              *      Step 2: translate from origin 0x0
              *              to where you want the image to be drawn.
              *              In this case to the center of the large
              *              view screen minus half the width and height
              *              of the playerImage.
              */
             transform.translate(MAIN_OFFSET[3] - (playerImage.getWidth() /2),MAIN_OFFSET[3] - (playerImage.getHeight() / 2));// locate at the player position
             /*
              *      Step 3: rotate about the center point of
              *              the playerImage by playerRotationAngle degrees.
              */
             transform.rotate(Math.toRadians(playerRotationAngle),playerImage.getHeight()/2,playerImage.getHeight()/2);
             /*
              *      Step 4: draw the rendered image to the Graphics,
              *              Graphics2D object (or literal Image object
              *              being used as a buffered image). In this case
              *              we draw it offscreen to our bufferGraphics
              *              image and it gets rendered later via
              *              double buffering.
              */
             bufferGraphics.drawRenderedImage(playerImage,transform);

            // BufferedImage tempRotatedImage = new BufferedImage(playerImage.getHeight(),playerImage.getWidth(), BufferedImage.TYPE_INT_RGB);
            // Graphics2D gR = tempRotatedImage.createGraphics();
            // gR.drawRenderedImage(playerImage,transform);
            // gR.dispose();


             // draw the playerMovePointer rectangle

             // bufferGraphics.draw(playerMovePointer);

             AffineTransform aT = bufferGraphics.getTransform();
             // AffineTransform af2 = AffineTransform.getRotateInstance(Math.toRadians(playerRotationAngle),0.0, 0.0);
             // AffineTransform af2 = AffineTransform.getRotateInstance(Math.toRadians(playerRotationAngle),scrollX, scrollY);
             // AffineTransform af2 = new AffineTransform();
             // af2.translate(MAIN_OFFSET[3] - (playerImage.getWidth() /2),MAIN_OFFSET[3] - (playerImage.getHeight() / 2));// locate at the player position

             AffineTransform af2 = new AffineTransform();
             af2.translate(20f,20f);
             bufferGraphics.transform(af2);
           //  AffineTransform af2 = AffineTransform.getRotateInstance(Math.toRadians(playerRotationAngle),
           //          MAIN_OFFSET[3] - (playerImage.getWidth() /2),MAIN_OFFSET[3] - (playerImage.getHeight() / 2));
           //  bufferGraphics.transform(af2);

             af2 = AffineTransform.getRotateInstance(Math.toRadians(playerRotationAngle),
                     MAIN_OFFSET[3] - (playerImage.getWidth() /2),MAIN_OFFSET[3] - (playerImage.getHeight() / 2));
             bufferGraphics.transform(af2);
             bufferGraphics.draw(playerMovePointer);
             bufferGraphics.setTransform(aT);// set it back
                                                                     
             /*
              *      Check triggers here and
              *      display message, trap graphics, etc.
              */
             checkTriggers();

            /*
             * Show offscreen image here
             */
             g.drawImage(offscreen,0,0,this);

    }        


    public void keyTyped(KeyEvent e){
    }


    public void keyPressed(KeyEvent e){
            switch( e.getKeyCode() ) {
                    case KeyEvent.VK_Q:
                          if(player_speed == 0){
                                  /*
                                   *    Rooted, in cut-scene, changed to
                                   *    stone, etc.
                                   */
                          }else{
                                  scrollX-=player_speed;// 10;
                                  scrollY-=player_speed;
                                  repaint();
                          }
                          break;
                    case KeyEvent.VK_E:
                          if(player_speed == 0){
                                  /*
                                   *    Rooted, in cut-scene, changed to
                                   *    stone, etc.
                                   */
                          }else{
                                  scrollX+=player_speed;
                                  scrollY-=player_speed;
                                  repaint();
                          }
                          break;
                    case KeyEvent.VK_C:
                          if(player_speed == 0){
                                  /*
                                   *    Rooted, in cut-scene, changed to
                                   *    stone, etc.
                                   */
                          }else{
                                  scrollX+=player_speed;
                                  scrollY+=player_speed;
                                  repaint();
                          }
                          break;
                    case KeyEvent.VK_Z:
                          if(player_speed == 0){
                                  /*
                                   *    Rooted, in cut-scene, changed to
                                   *    stone, etc.
                                   */
                          }else{
                                  scrollX-=player_speed;
                                  scrollY+=player_speed;
                                  repaint();
                          }
                          break;
                    case KeyEvent.VK_LEFT:
                          playerRotationAngle-=10;
                          if(playerRotationAngle < 0f) playerRotationAngle = 360f;
                          repaint();
                          break;
                    case KeyEvent.VK_A:
                          if(player_speed == 0){
                                  /*
                                   *    Rooted, in cut-scene, changed to
                                   *    stone, etc.
                                   */
                          }else{
                                  scrollX-=player_speed;
                                  repaint();
                          }
                          break;
                    case KeyEvent.VK_RIGHT:
                          playerRotationAngle+=10;
                          if(playerRotationAngle > 360f) playerRotationAngle = 0f;
                          repaint();
                          break;
                    case KeyEvent.VK_D:
                          if(player_speed == 0){
                                  /*
                                   *    Rooted, in cut-scene, changed to
                                   *    stone, etc.
                                   */
                          }else{
                                  scrollX+=player_speed;
                                  repaint();
                          }
                          break;
                    case KeyEvent.VK_UP:
                    case KeyEvent.VK_W:
                          if(player_speed == 0){
                                  /*
                                   *    Rooted, in cut-scene, changed to
                                   *    stone, etc.
                                   */
                          }else{
                                  scrollY-=player_speed;
                                  repaint();
                          }
                          break;
                    case KeyEvent.VK_DOWN:
                    case KeyEvent.VK_X:
                          if(player_speed == 0){
                                  /*
                                   *    Rooted, in cut-scene, changed to
                                   *    stone, etc.
                                   */
                          }else{
                                  scrollY+=player_speed;
                                  repaint();
                          }
                          break;
                    case KeyEvent.VK_B:
                          if(isApplication == Boolean.TRUE){
                                  System.out.println("Total memory: " +
                                  Runtime.getRuntime().totalMemory());
                                  System.out.println("Free memory: " +
                                  Runtime.getRuntime().freeMemory());
                                  System.out.println("Exiting application...");
                                  System.exit(0);// only works in Application mode!
                          }else{
                                  System.out.println("Exiting applet...");
                                  // stop();
                          }
                          break;
                    case KeyEvent.VK_L:
                          if(draw_large_map == false){
                                  draw_large_map = true;
                          }else{
                                  draw_large_map = false;
                          }
                          repaint();
                          break;
                    case KeyEvent.VK_S:
                          // speed toggler - for test only, not production
                          if(player_speed == 5){
                                  player_speed = 12;// run
                          }else{
                                  player_speed = 5;// walk
                          }
                          break;
                    case KeyEvent.VK_SPACE:
                          System.out.println("bang!");
                          // bufferGraphics.fillRect(
                          // tempImage, ix, iy,this);
                    default:
                          break;
            }
            // repaint();
            // e.consume();
    }


    public void keyReleased(KeyEvent e){ }

    /*
     *      For now this checks it assuming the triggered-by object
     *      is the player. Otherwise in the future should pass an
     *      object here in case an NPC should set off the triggered event.
     */
    public void checkTriggers(){
            int locX = 500;
            int locY = 500;
            Rectangle trap1 = new Rectangle(locX,locY,50,50);
            Rectangle player1 = new Rectangle(scrollX, scrollY, 128, 128);

            if(draw_large_map == false){
                    // our first test trigger
                    bufferGraphics.setColor(Color.red);
                    /*
                     *      Key here is to subtract player X & Y coords from
                     *      the non-player object (or sprite, etc.) to locate
                     *      it properly on the map.
                     */
                    bufferGraphics.fillRect(locX - scrollX + MAIN_OFFSET[1], locY - scrollY + MAIN_OFFSET[1], 50,50);

                    if(player1.intersects(trap1)){
                            bufferGraphics.setColor(Color.white);
                            bufferGraphics.fillRect(locX - scrollX + MAIN_OFFSET[1], locY - scrollY + MAIN_OFFSET[1], 50,50);
                            System.out.println("[trap triggered]");
                       //     Component ccc = getGlassPane();

                        //    ccc.drawString("hello world!");
                         //   player_speed = 0;// Root payer!
                         //   bufferGraphics.drawString("Rooted!",
                         //   locX - scrollX + MAIN_OFFSET[1],
                         //   locY - scrollY + MAIN_OFFSET[1]);
                    }
            }else{
                    // large map handling has different offsets
                    bufferGraphics.setColor(Color.red);
                    /*
                     *      Key here is to subtract player X & Y coords from
                     *      the non-player object (or sprite, etc.) to locate
                     *      it properly on the map.
                     */
                    bufferGraphics.fillRect(locX - scrollX + MAIN_OFFSET[2] + 64, locY - scrollY + MAIN_OFFSET[2] + 64, 50,50);

                    if(player1.intersects(trap1)){
                            bufferGraphics.setColor(Color.white);
                            bufferGraphics.fillRect(locX - scrollX + MAIN_OFFSET[2] + 64, locY - scrollY + MAIN_OFFSET[2] + 64, 50,50);
                            System.out.println("[trap triggered]");
                    }
                    
            }
    }


}



